package com.nice.launcher

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.sin

private const val TAU = 6.2831855f

fun makeSeeds(n: Int): List<FloatArray> {
    val r = kotlin.random.Random(7)
    return List(n) { floatArrayOf(r.nextFloat(), r.nextFloat(), 0.25f + r.nextFloat() * 0.75f, r.nextFloat()) }
}

/** Draws one animated background style. Shared by the live backdrop and the settings thumbnails. */
fun DrawScope.drawBackdropStyle(
    style: BackdropStyle, ui: Ui, t: Float, loop: Float, fast: Float,
    density: Float, seeds: List<FloatArray>, withParticles: Boolean = true
) {
    val w = size.width
    val h = size.height
    when (style) {
        BackdropStyle.BLOBS -> {
            val b = if (ui.look.blob > 0f) ui.look.blob else 0.35f
            val c1 = Offset(w * (0.15f + 0.7f * t), h * (0.2f + 0.1f * t))
            val c2 = Offset(w * (0.85f - 0.7f * t), h * (0.75f - 0.1f * t))
            drawCircle(Brush.radialGradient(listOf(ui.accent.copy(b), Color.Transparent), center = c1, radius = w), radius = w, center = c1)
            drawCircle(Brush.radialGradient(listOf(ui.accent2.copy(b * 0.8f), Color.Transparent), center = c2, radius = w), radius = w, center = c2)
        }
        BackdropStyle.STARS -> {
            val cnt = (110 * density).toInt().coerceIn(0, seeds.size)
            for (i in 0 until cnt) {
                val s = seeds[i]
                val tw = 0.5f + 0.5f * sin(loop * TAU * (1 + (s[2] * 3).toInt()) + s[3] * TAU)
                drawCircle(Color.White.copy(0.15f + 0.65f * tw * s[2]), radius = 1f + 2.4f * s[2], center = Offset(s[0] * w, s[1] * h))
            }
        }
        BackdropStyle.RAIN -> {
            val cnt = (80 * density).toInt().coerceIn(0, seeds.size)
            for (i in 0 until cnt) {
                val s = seeds[i]
                val y = ((s[1] + fast * (1 + (s[2] * 2).toInt())) % 1f) * (h + 80f) - 40f
                val x = s[0] * w
                drawLine(
                    ui.accent.copy(0.15f + 0.35f * s[2]), Offset(x, y), Offset(x - 5f, y + 20f + 42f * s[2]),
                    strokeWidth = 1.5f + s[2], cap = StrokeCap.Round
                )
            }
        }
        BackdropStyle.GRID -> {
            val hz = h * 0.55f
            drawCircle(
                Brush.radialGradient(listOf(ui.accent2.copy(0.45f), Color.Transparent), center = Offset(w / 2, hz), radius = w * 0.45f),
                radius = w * 0.45f, center = Offset(w / 2, hz)
            )
            for (k in 0 until 14) {
                val f = (k + fast) / 14f
                val y = hz + (h - hz) * f * f
                drawLine(ui.accent.copy(0.10f + 0.5f * f), Offset(0f, y), Offset(w, y), strokeWidth = 1.5f)
            }
            for (i in -8..8) {
                drawLine(ui.accent2.copy(0.28f), Offset(w / 2 + i * w * 0.03f, hz), Offset(w / 2 + i * w * 0.30f, h), strokeWidth = 1.5f)
            }
        }
        BackdropStyle.WAVES -> {
            for (k in 0 until 3) {
                val base = h * (0.62f + 0.09f * k)
                val amp = h * 0.025f * (1 + k)
                val path = Path()
                path.moveTo(0f, h)
                var x = 0f
                while (x <= w + 12f) {
                    val y = base + amp * sin(x / w * TAU * (1.2f + k * 0.5f) + loop * TAU * (k + 1))
                    path.lineTo(x, y)
                    x += 12f
                }
                path.lineTo(w, h)
                path.close()
                drawPath(path, (if (k % 2 == 0) ui.accent else ui.accent2).copy(0.16f))
            }
        }
        BackdropStyle.NONE, BackdropStyle.AUTO -> { }
    }
    val pc = if (withParticles && ui.particles) minOf(ui.quality.particles, seeds.size) else 0
    for (i in 0 until pc) {
        val s = seeds[(i + 53) % seeds.size]
        val y = (((s[1] - loop * (1 + (s[2] * 2).toInt())) % 1f) + 1f) % 1f * h
        val x = s[0] * w + sin(loop * TAU * 2 + s[3] * TAU) * 12f
        drawCircle(ui.accent2.copy(0.12f + 0.3f * s[3]), radius = 2f + 4f * s[2], center = Offset(x, y))
    }
}

@Composable
fun Backdrop(ui: Ui) {
    val style = when (ui.backdrop) {
        BackdropStyle.AUTO -> if (ui.look.blob > 0f) BackdropStyle.BLOBS else BackdropStyle.NONE
        else -> ui.backdrop
    }
    val seeds = remember { makeSeeds(160) }
    val inf = rememberInfiniteTransition(label = "bg")
    val animate = ui.quality.anim
    val tS = if (animate) inf.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "t") else null
    val loopS = if (animate) inf.animateFloat(0f, 1f, infiniteRepeatable(tween(24000, easing = LinearEasing)), label = "loop") else null
    val fastS = if (animate) inf.animateFloat(0f, 1f, infiniteRepeatable(tween(4000, easing = LinearEasing)), label = "fast") else null
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(ui.look.top, ui.look.bottom)))
        drawBackdropStyle(
            style, ui, tS?.value ?: 0.5f, loopS?.value ?: 0.3f, fastS?.value ?: 0.2f,
            ui.quality.density, seeds
        )
    }
}

@Composable
fun BackdropThumb(style: BackdropStyle, selected: Boolean, ui: Ui, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val seeds = remember { makeSeeds(160) }
    Column(
        Modifier.width(88.dp).clickable { Sfx.play(Sound.TOGGLE); onClick() },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Canvas(
            Modifier.size(88.dp, 112.dp).clip(shape)
                .border(if (selected) 3.dp else 1.dp, if (selected) Color.White else Color.White.copy(0.2f), shape)
        ) {
            drawRect(Color(0xFF12122A))
            drawRect(Brush.verticalGradient(listOf(ui.look.top, ui.look.bottom)))
            val st = if (style == BackdropStyle.AUTO) (if (ui.look.blob > 0f) BackdropStyle.BLOBS else BackdropStyle.NONE) else style
            drawBackdropStyle(st, ui, 0.5f, 0.3f, 0.2f, 0.6f, seeds, withParticles = false)
        }
        Text(style.title, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun HomeThumb(s: HomeStyle, selected: Boolean, ui: Ui, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier.width(88.dp).clickable { Sfx.play(Sound.TOGGLE); onClick() },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Canvas(
            Modifier.size(88.dp, 112.dp).clip(shape)
                .border(if (selected) 3.dp else 1.dp, if (selected) Color.White else Color.White.copy(0.2f), shape)
        ) {
            drawRect(Color(0xFF0A0A14))
            val w = size.width
            val h = size.height
            if (s.hud) {
                val c = Offset(w / 2, h * 0.46f)
                val r = w * 0.38f
                drawCircle(Brush.radialGradient(listOf(s.c1.copy(0.3f), Color.Transparent), center = c, radius = r * 1.3f), radius = r * 1.3f, center = c)
                drawCircle(s.c1, radius = r, center = c, style = Stroke(2.5f))
                drawCircle(s.c1.copy(0.6f), radius = r * 0.7f, center = c, style = Stroke(1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))))
                drawArc(s.c2, 200f, 80f, false, topLeft = Offset(c.x - r * 0.5f, c.y - r * 0.5f), size = Size(r, r), style = Stroke(3f, cap = StrokeCap.Round))
                drawCircle(s.c1.copy(0.4f), radius = r * 0.28f, center = c)
                drawRoundRect(s.c1.copy(0.7f), Offset(w * 0.12f, h * 0.86f), Size(w * 0.76f, h * 0.08f), CornerRadius(8f))
            } else {
                drawRoundRect(Color.White.copy(0.9f), Offset(w * 0.2f, h * 0.12f), Size(w * 0.6f, h * 0.09f), CornerRadius(8f))
                drawRoundRect(Color.White.copy(0.35f), Offset(w * 0.3f, h * 0.25f), Size(w * 0.4f, h * 0.04f), CornerRadius(4f))
                for (row in 0 until 3) for (col in 0 until 3) {
                    drawRoundRect(
                        s.c1.copy(0.55f), Offset(w * (0.14f + col * 0.27f), h * (0.38f + row * 0.15f)),
                        Size(w * 0.2f, w * 0.2f), CornerRadius(14f)
                    )
                }
                drawRoundRect(Color.White.copy(0.18f), Offset(w * 0.1f, h * 0.86f), Size(w * 0.8f, h * 0.09f), CornerRadius(14f))
            }
        }
        Text(s.title, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    }
}
