package com.nice.launcher

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontFamily
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

val Accents = listOf(
    Color(0xFF7C4DFF), Color(0xFF00E5FF), Color(0xFFFF4081),
    Color(0xFF69F0AE), Color(0xFFFFAB40), Color(0xFF448AFF)
)

enum class IconShape(val title: String, val shape: Shape) {
    CIRCLE("Circle", RoundedCornerShape(50)),
    SQUIRCLE("Squircle", RoundedCornerShape(32)),
    ROUNDED("Rounded", RoundedCornerShape(16)),
    TEARDROP("Teardrop", RoundedCornerShape(50, 50, 50, 12)),
    SQUARE("Square", RoundedCornerShape(4))
}

enum class Look(
    val title: String, val light: Boolean, val text: Color, val top: Color, val bottom: Color,
    val card: Color, val glassy: Boolean, val radius: Int, val glow: Boolean, val blob: Float,
    val centered: Boolean, val font: FontFamily, val drawerScrim: Color
) {
    LIQUID("Liquid Glass", false, Color.White, Color(0x22000000), Color(0x77000000), Color.White, true, 30, false, 0.30f, true, FontFamily.Default, Color(0x66000000)),
    CLASSIC("One UI Classic", false, Color.White, Color(0x33000000), Color(0x99000000), Color(0xEB26262B), false, 28, false, 0f, false, FontFamily.Default, Color(0xCC0C0C10)),
    NEON("Neon Cyber", false, Color(0xFFEAFBFF), Color(0xE6050510), Color(0xF2000000), Color(0x99080818), false, 18, true, 0.35f, false, FontFamily.SansSerif, Color(0xE6000000)),
    AURORA("Aurora", false, Color.White, Color(0x55000022), Color(0x99000011), Color.White, true, 34, false, 0.55f, true, FontFamily.Default, Color(0x99000018)),
    PAPER("Paper", true, Color(0xFF1C1B1F), Color(0xCCF6F1E7), Color(0xE6E9E0D0), Color(0xCCFFFFFF), false, 26, false, 0f, true, FontFamily.Serif, Color(0xEBF6F1E7)),
    TERMINAL("Terminal", false, Color(0xFF39FF14), Color(0xF5000000), Color(0xF5000000), Color(0xB3001400), false, 4, false, 0f, false, FontFamily.Monospace, Color(0xF5000000));

    fun stroke(accent: Color): Brush = when (this) {
        LIQUID, AURORA -> Brush.linearGradient(listOf(Color.White.copy(0.7f), Color.White.copy(0.05f), Color.White.copy(0.35f)))
        NEON -> SolidColor(accent)
        TERMINAL -> SolidColor(text.copy(0.7f))
        PAPER -> SolidColor(Color.Black.copy(0.08f))
        CLASSIC -> SolidColor(Color.White.copy(0.08f))
    }
}

enum class HomeStyle(val title: String, val hud: Boolean, val c1: Color, val c2: Color, val ticks: Int, val sweep: Boolean) {
    STANDARD("Standard", false, Color(0xFF7C4DFF), Color(0xFFFFFFFF), 60, false),
    REACTOR("Reactor", true, Color(0xFFFF2D55), Color(0xFFFFB300), 60, false),
    ORBIT("Orbit", true, Color(0xFF00E5FF), Color(0xFFB2EBF2), 36, false),
    RADAR("Radar", true, Color(0xFF39FF14), Color(0xFFCCFF90), 72, true),
    SOLAR("Solar", true, Color(0xFFFFC400), Color(0xFFFF6D00), 48, false),
    ICE("Ice", true, Color(0xFF82B1FF), Color(0xFFE1F5FE), 90, true)
}

enum class Quality(val title: String, val anim: Boolean, val particles: Int, val density: Float) {
    LOW("Battery saver", false, 0, 0.5f),
    MEDIUM("Balanced", true, 24, 0.8f),
    HIGH("High", true, 60, 1.1f),
    ULTRA("Ultra", true, 110, 1.6f)
}

enum class BackdropStyle(val title: String) {
    AUTO("Auto"), BLOBS("Blobs"), STARS("Starfield"), WAVES("Waves"), GRID("Cyber grid"), RAIN("Rain"), NONE("Plain")
}

enum class ClockStyle(val title: String) {
    DIGITAL("Digital"), STACKED("Stacked"), ANALOG("Analog"), RING("Ring"), WORDS("Words")
}

enum class IconTint(val title: String) {
    AUTO("Auto"), ORIGINAL("Original"), MONO("Mono"), ACCENT("Accent"), RAINBOW("Rainbow"), CUSTOM("Custom")
}

class Widget(val id: String, val name: String, val html: String, val height: Int, val onHome: Boolean)

class LauncherSettings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("nice_launcher", Context.MODE_PRIVATE)
    private fun list(k: String) = (sp.getString(k, "") ?: "").split(",").filter { it.isNotBlank() }

    var apiKey by mutableStateOf(sp.getString("key", "") ?: "")
    var model by mutableStateOf(sp.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini")
    var look by mutableStateOf(runCatching { Look.valueOf(sp.getString("look", "LIQUID")!!) }.getOrDefault(Look.LIQUID))
    var shape by mutableStateOf(runCatching { IconShape.valueOf(sp.getString("shape", "SQUIRCLE")!!) }.getOrDefault(IconShape.SQUIRCLE))
    var accent by mutableStateOf(sp.getInt("accent", 0))
    var glass by mutableStateOf(sp.getFloat("glass", 0.18f))
    var iconSize by mutableStateOf(sp.getFloat("isize", 56f))
    var columns by mutableStateOf(sp.getInt("cols", 4))
    var homeCols by mutableStateOf(sp.getInt("hcols", 4))
    var labels by mutableStateOf(sp.getBoolean("labels", true))
    var blur by mutableStateOf(sp.getBoolean("blur", true))
    var dock by mutableStateOf(list("dock"))
    var home by mutableStateOf(list("home"))
    var recents by mutableStateOf(list("recents"))
    var note by mutableStateOf(sp.getString("note", "") ?: "")
    var homeStyle by mutableStateOf(runCatching { HomeStyle.valueOf(sp.getString("hstyle", "STANDARD")!!) }.getOrDefault(HomeStyle.STANDARD))
    var clock by mutableStateOf(runCatching { ClockStyle.valueOf(sp.getString("clock", "DIGITAL")!!) }.getOrDefault(ClockStyle.DIGITAL))
    var tint by mutableStateOf(runCatching { IconTint.valueOf(sp.getString("tint", "AUTO")!!) }.getOrDefault(IconTint.AUTO))
    var tintHex by mutableStateOf(sp.getString("tinthex", "#FF4081") ?: "#FF4081")
    var sfx by mutableStateOf(sp.getBoolean("sfx", true))
    var sfxVol by mutableStateOf(sp.getFloat("sfxvol", 0.7f))
    var quality by mutableStateOf(runCatching { Quality.valueOf(sp.getString("quality", "HIGH")!!) }.getOrDefault(Quality.HIGH))
    var backdrop by mutableStateOf(runCatching { BackdropStyle.valueOf(sp.getString("backdrop", "AUTO")!!) }.getOrDefault(BackdropStyle.AUTO))
    var particles by mutableStateOf(sp.getBoolean("particles", true))
    var threeD by mutableStateOf(runCatching { ThreeD.valueOf(sp.getString("threed", "OFF")!!) }.getOrDefault(ThreeD.OFF))
    var depth by mutableStateOf(sp.getFloat("depth", 0.6f))
    var motion by mutableStateOf(sp.getBoolean("motion", true))
    var pageFx by mutableStateOf(sp.getBoolean("pagefx", true))
    var openAnim by mutableStateOf(runCatching { PanelAnim.valueOf(sp.getString("openanim", "SLIDE")!!) }.getOrDefault(PanelAnim.SLIDE))
    var closeAnim by mutableStateOf(runCatching { PanelAnim.valueOf(sp.getString("closeanim", "SLIDE")!!) }.getOrDefault(PanelAnim.SLIDE))
    var animSpeed by mutableStateOf(sp.getFloat("animspeed", 1f))
    var launchAnim by mutableStateOf(runCatching { LaunchAnim.valueOf(sp.getString("launchanim", "SYSTEM")!!) }.getOrDefault(LaunchAnim.SYSTEM))
    var foldFx by mutableStateOf(sp.getBoolean("foldfx", true))
    var barStyle by mutableStateOf(runCatching { BarStyle.valueOf(sp.getString("barstyle", "ISLAND")!!) }.getOrDefault(BarStyle.ISLAND))
    var barColor by mutableStateOf(runCatching { BarColor.valueOf(sp.getString("barcolor", "BLACK")!!) }.getOrDefault(BarColor.BLACK))
    var barHex by mutableStateOf(sp.getString("barhex", "#FF4081") ?: "#FF4081")
    var barAlpha by mutableStateOf(sp.getFloat("baralpha", 1f))
    var barPadY by mutableStateOf(sp.getFloat("barpady", 7f))
    var barRadius by mutableStateOf(sp.getFloat("barradius", 24f))
    var barText by mutableStateOf(sp.getFloat("bartext", 13f))
    var barClock by mutableStateOf(sp.getBoolean("barclock", false))
    var barDate by mutableStateOf(sp.getBoolean("bardate", false))
    var barBattery by mutableStateOf(sp.getBoolean("barbattery", true))
    var barNotifs by mutableStateOf(sp.getBoolean("barnotifs", true))
    var barMusic by mutableStateOf(sp.getBoolean("barmusic", true))
    var barBorder by mutableStateOf(sp.getBoolean("barborder", true))
    var barGlow by mutableStateOf(sp.getBoolean("barglow", false))
    var barPos by mutableStateOf(runCatching { BarPos.valueOf(sp.getString("barpos", "CENTER")!!) }.getOrDefault(BarPos.CENTER))
    var barTop by mutableStateOf(sp.getFloat("bartop", 8f))
    var widgets by mutableStateOf(loadWidgets())

    fun barCfg(): BarCfg = BarCfg(
        barStyle, barColor,
        try { Color(android.graphics.Color.parseColor(barHex.trim())) } catch (e: Exception) { Color(0xFFFF4081) },
        barAlpha, barPadY, barRadius, barText, barClock, barDate, barBattery, barNotifs, barMusic, barBorder, barGlow, barPos, barTop
    )

    private fun loadWidgets(): List<Widget> = try {
        val a = JSONArray(sp.getString("widgets", "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Widget(o.getString("id"), o.getString("name"), o.getString("html"), o.optInt("height", 140), o.optBoolean("home", false))
        }
    } catch (e: Exception) { emptyList() }

    fun addWidget(name: String, html: String, height: Int, onHome: Boolean) {
        widgets = widgets + Widget(System.currentTimeMillis().toString(), name, html, height, onHome)
        save()
    }

    private fun widgetsJson(): String {
        val a = JSONArray()
        for (w in widgets) {
            a.put(JSONObject().put("id", w.id).put("name", w.name).put("html", w.html).put("height", w.height).put("home", w.onHome))
        }
        return a.toString()
    }

    fun save() {
        sp.edit()
            .putString("key", apiKey).putString("model", model)
            .putString("look", look.name).putString("shape", shape.name)
            .putInt("accent", accent).putFloat("glass", glass).putFloat("isize", iconSize)
            .putInt("cols", columns).putInt("hcols", homeCols)
            .putBoolean("labels", labels).putBoolean("blur", blur)
            .putString("dock", dock.joinToString(",")).putString("home", home.joinToString(","))
            .putString("recents", recents.joinToString(",")).putString("note", note)
            .putString("hstyle", homeStyle.name).putString("clock", clock.name)
            .putString("tint", tint.name).putString("tinthex", tintHex)
            .putBoolean("sfx", sfx).putFloat("sfxvol", sfxVol)
            .putString("quality", quality.name).putString("backdrop", backdrop.name).putBoolean("particles", particles)
            .putString("widgets", widgetsJson())
            .putString("threed", threeD.name).putFloat("depth", depth).putBoolean("motion", motion).putBoolean("pagefx", pageFx)
            .putString("openanim", openAnim.name).putString("closeanim", closeAnim.name).putFloat("animspeed", animSpeed)
            .putString("launchanim", launchAnim.name).putBoolean("foldfx", foldFx)
            .putString("barstyle", barStyle.name).putString("barcolor", barColor.name).putString("barhex", barHex)
            .putFloat("baralpha", barAlpha).putFloat("barpady", barPadY).putFloat("barradius", barRadius).putFloat("bartext", barText)
            .putBoolean("barclock", barClock).putBoolean("bardate", barDate).putBoolean("barbattery", barBattery)
            .putBoolean("barnotifs", barNotifs).putBoolean("barmusic", barMusic).putBoolean("barborder", barBorder)
            .putBoolean("barglow", barGlow).putString("barpos", barPos.name).putFloat("bartop", barTop)
            .apply()
    }
}

class AppItem(val label: String, val pkg: String, val icon: ImageBitmap)

private val iconCache = HashMap<String, ImageBitmap>()

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(q, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .distinctBy { it.activityInfo.packageName }
        .map { ri ->
            val p = ri.activityInfo.packageName
            AppItem(
                ri.loadLabel(pm).toString(), p,
                iconCache.getOrPut(p) { ri.loadIcon(pm).toBitmap(160, 160).asImageBitmap() }
            )
        }
        .sortedBy { it.label.lowercase() }
}

object Ai {
    private const val SYSTEM = """You are the assistant built into an Android launcher called Nice UI 10. The user gives you commands. 
Respond ONLY with a JSON object: {"say": "short friendly reply", "actions": [ ... ]}.
Available action objects:
{"type":"open_app","name":"App name"}
{"type":"open_url","url":"https://..."}
{"type":"web_search","query":"..."}
{"type":"set_timer","seconds":600,"label":"..."}
{"type":"set_alarm","hour":7,"minute":30,"label":"..."}
{"type":"call","number":"+123456789"}
{"type":"set_look","name":"liquid|classic|neon|aurora|paper|terminal"}
{"type":"set_accent","color":"purple|cyan|pink|green|orange|blue"}
{"type":"set_icon_shape","shape":"circle|squircle|rounded|teardrop|square"}
{"type":"pin_app","name":"App name","where":"dock|home"}
{"type":"add_note","text":"..."}
{"type":"set_home_style","name":"standard|reactor|orbit|radar|solar|ice"}
{"type":"set_clock","style":"digital|stacked|analog|ring|words"}
{"type":"set_icon_tint","mode":"original|mono|accent|rainbow|custom","color":"#RRGGBB (only for custom)"}
{"type":"set_quality","name":"low|medium|high|ultra"}
{"type":"set_backdrop","name":"auto|blobs|stars|waves|grid|rain|none"}
{"type":"set_sound","on":true,"volume":0.7}
{"type":"set_3d","mode":"off|subtle|full"}
{"type":"set_animation","open":"slide|zoom|fade|flip|unfold|depth|bounce","close":"slide|zoom|fade|flip|unfold|depth|bounce"}
{"type":"create_widget","name":"...","html":"compact HTML with inline <style> and <script>","height":140,"on_home":false}
Widgets render in a small transparent web view. CSS variables --accent and --text are available, and Nice.openApp('Name'), Nice.battery(), Nice.vibrate(ms), Nice.toast('text'), Nice.sound('tap') and Nice.openUrl(url) exist in JavaScript. localStorage works.
You can restyle the launcher with set_look, set_accent and set_icon_shape when asked to change how it looks.
Use an empty actions array for plain conversation. Only include actions the user asked for."""

    suspend fun ask(key: String, model: String, history: List<Pair<String, String>>): JSONObject =
        withContext(Dispatchers.IO) {
            val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", SYSTEM))
            history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
            val body = JSONObject()
                .put("model", model)
                .put("response_format", JSONObject().put("type", "json_object"))
                .put("messages", msgs)
            val c = URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Content-Type", "application/json")
            c.doOutput = true
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = try { JSONObject(text).getJSONObject("error").getString("message") } catch (e: Exception) { text.take(200) }
                throw IllegalStateException("OpenAI error $code: $msg")
            }
            val content = JSONObject(text).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
            JSONObject(content)
        }
}
