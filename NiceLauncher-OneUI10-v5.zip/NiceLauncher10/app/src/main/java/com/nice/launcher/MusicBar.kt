@file:OptIn(ExperimentalFoundationApi::class)

package com.nice.launcher

import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.luminance
import kotlinx.coroutines.delay
import java.time.LocalTime
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.DateTimeFormatter

enum class Glyph { PLAY, PAUSE, NEXT, PREV }

@Composable
fun GlyphIcon(g: Glyph, color: Color, dp: Dp) {
    Canvas(Modifier.size(dp)) {
        val w = this.size.width
        val h = this.size.height
        when (g) {
            Glyph.PLAY -> {
                val p = Path()
                p.moveTo(w * 0.30f, h * 0.18f); p.lineTo(w * 0.84f, h * 0.5f); p.lineTo(w * 0.30f, h * 0.82f); p.close()
                drawPath(p, color)
            }
            Glyph.PAUSE -> {
                drawRoundRect(color, Offset(w * 0.25f, h * 0.2f), Size(w * 0.18f, h * 0.6f), CornerRadius(w * 0.05f))
                drawRoundRect(color, Offset(w * 0.57f, h * 0.2f), Size(w * 0.18f, h * 0.6f), CornerRadius(w * 0.05f))
            }
            Glyph.NEXT -> {
                val p = Path()
                p.moveTo(w * 0.20f, h * 0.22f); p.lineTo(w * 0.64f, h * 0.5f); p.lineTo(w * 0.20f, h * 0.78f); p.close()
                drawPath(p, color)
                drawRoundRect(color, Offset(w * 0.70f, h * 0.22f), Size(w * 0.11f, h * 0.56f), CornerRadius(w * 0.04f))
            }
            Glyph.PREV -> {
                val p = Path()
                p.moveTo(w * 0.80f, h * 0.22f); p.lineTo(w * 0.36f, h * 0.5f); p.lineTo(w * 0.80f, h * 0.78f); p.close()
                drawPath(p, color)
                drawRoundRect(color, Offset(w * 0.19f, h * 0.22f), Size(w * 0.11f, h * 0.56f), CornerRadius(w * 0.04f))
            }
        }
    }
}

@Composable
fun GlyphButton(g: Glyph, color: Color, onClick: () -> Unit) {
    Box(Modifier.size(46.dp).clip(CircleShape).clickable { onClick() }, contentAlignment = Alignment.Center) {
        GlyphIcon(g, color, 26.dp)
    }
}

@Composable
fun MediaArt(m: MediaInfo, dp: Dp, shape: Shape, tint: Color, modifier: Modifier = Modifier) {
    Box(modifier.size(dp).clip(shape).background(tint.copy(0.35f)), contentAlignment = Alignment.Center) {
        val art = m.art
        if (art != null) {
            Image(art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text("♪", color = Color.White, fontSize = (dp.value * 0.5f).sp)
        }
    }
}

@Composable
fun SeekBar(frac: Float, color: Color, onSeek: (Float) -> Unit, modifier: Modifier = Modifier) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val seek by rememberUpdatedState(onSeek)
    val shown = drag ?: frac
    Canvas(
        modifier.fillMaxWidth().height(22.dp)
            .pointerInput(Unit) {
                detectTapGestures(onTap = { o -> seek((o.x / size.width).coerceIn(0f, 1f)) })
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> drag = (o.x / size.width).coerceIn(0f, 1f) },
                    onDragEnd = { drag?.let { seek(it) }; drag = null },
                    onDragCancel = { drag = null },
                    onHorizontalDrag = { change, _ -> drag = (change.position.x / size.width).coerceIn(0f, 1f) }
                )
            }
    ) {
        val cy = size.height / 2
        val th = 5.dp.toPx()
        drawRoundRect(Color.White.copy(0.2f), Offset(0f, cy - th / 2), Size(size.width, th), CornerRadius(th / 2))
        drawRoundRect(color, Offset(0f, cy - th / 2), Size(size.width * shown, th), CornerRadius(th / 2))
        drawCircle(Color.White, 7.dp.toPx(), Offset(size.width * shown, cy))
    }
}

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

/** Clock, date, battery and notification icons shown on the collapsed bar, according to the user's bar settings. */
@Composable
private fun BarInfo(bar: BarCfg, battery: Int, fg: Color, apps: List<AppItem>, onNotifs: () -> Unit) {
    var now by remember { mutableStateOf(LocalTime.now()) }
    LaunchedEffect(bar.showClock) { while (bar.showClock) { now = LocalTime.now(); delay(10_000) } }
    val sz = bar.text.sp
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (bar.showNotifs && NotifHub.pkgs.isNotEmpty()) {
            Row(
                Modifier.clickable { Sfx.play(Sound.TAP); onNotifs() },
                horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                NotifHub.pkgs.take(4).forEach { p ->
                    apps.find { it.pkg == p }?.let { a ->
                        Image(a.icon, null, Modifier.size((bar.text + 5f).dp).clip(CircleShape))
                    }
                }
                if (NotifHub.count > 4) Text("+${NotifHub.count - 4}", color = fg, fontSize = (bar.text - 2f).sp)
            }
        }
        if (bar.showClock) Text(now.format(DateTimeFormatter.ofPattern("HH:mm")), color = fg, fontSize = sz, fontWeight = FontWeight.Medium)
        if (bar.showDate) Text(LocalDate.now().format(DateTimeFormatter.ofPattern("EEE d MMM")), color = fg.copy(0.8f), fontSize = sz)
        if (bar.showBattery) Text("$battery%", color = fg, fontSize = sz)
    }
}

/**
 * Editable top bar. Style: Island (pill), Wide bar (full width) or Mini (tiny dot). Collapsed it shows the song,
 * notification icons, clock, date and battery as chosen in Settings > Notification bar. Tap it to open the full player.
 */
@Composable
fun Island(
    ui: Ui, battery: Int, mediaIn: MediaInfo?, onAi: () -> Unit,
    onSeek: (Long) -> Unit = {}, onOpenPlayer: () -> Unit = {},
    bar: BarCfg = BarCfg(), apps: List<AppItem> = emptyList(), onNotifs: () -> Unit = {},
    onCmd: (String) -> Unit
) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    val media = if (bar.showMusic) mediaIn else null
    val tint = media?.tint ?: ui.accent
    val expanded = open && media != null
    val corner by animateDpAsState(if (expanded) 30.dp else bar.radius.dp, label = "corner")
    val shape = RoundedCornerShape(corner)
    val target = if (media != null && media.dur > 0) (media.pos.toFloat() / media.dur).coerceIn(0f, 1f) else 0f
    val frac by animateFloatAsState(target, tween(900, easing = LinearEasing), label = "prog")

    val base = when (bar.color) {
        BarColor.BLACK -> Color.Black
        BarColor.ACCENT -> ui.accent
        BarColor.GLASS -> Color.White
        BarColor.CUSTOM -> bar.custom
    }
    val bg = if (bar.color == BarColor.GLASS) base.copy(0.08f + 0.22f * bar.alpha) else base.copy(bar.alpha)
    val fg = if (bar.color != BarColor.GLASS && base.luminance() > 0.6f && bar.alpha > 0.5f) Color.Black else Color.White
    val wide = bar.style == BarStyle.WIDE
    val mini = bar.style == BarStyle.MINI
    val vPad = bar.padY.dp
    val hPad = if (mini) 10.dp else 12.dp

    Column(
        Modifier
            .then(if (expanded || wide) Modifier.fillMaxWidth(0.94f) else Modifier)
            .then(if (bar.glow) Modifier.shadow(10.dp, shape, ambientColor = ui.accent, spotColor = ui.accent) else Modifier)
            .animateContentSize(spring(dampingRatio = 0.7f, stiffness = 350f))
            .clip(shape).background(bg)
            .drawBehind {
                if (media != null) {
                    val f = if (expanded) 1f else frac
                    drawRect(tint.copy(if (expanded) 0.22f else 0.30f), size = Size(size.width * f, size.height))
                }
            }
            .then(if (bar.border) Modifier.border(1.dp, ui.look.stroke(ui.accent), shape) else Modifier)
            .clickable { Sfx.play(Sound.TAP); open = !open }
    ) {
        if (media != null && !open) {
            Row(
                (if (wide) Modifier.fillMaxWidth() else Modifier).padding(horizontal = hPad, vertical = vPad),
                verticalAlignment = Alignment.CenterVertically
            ) {
                MediaArt(media, (bar.text * 1.85f).dp, CircleShape, tint)
                Spacer(Modifier.width(8.dp))
                Text(
                    media.title, color = fg, fontSize = bar.text.sp, maxLines = 1,
                    modifier = (if (wide) Modifier.weight(1f) else Modifier.widthIn(max = 130.dp)).basicMarquee(iterations = Int.MAX_VALUE)
                )
                Spacer(Modifier.width(8.dp))
                EqBars(tint, media.playing)
                if (!mini) {
                    Spacer(Modifier.width(8.dp))
                    BarInfo(bar, battery, fg, apps, onNotifs)
                }
            }
        } else if (media != null) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    MediaArt(
                        media, 60.dp, RoundedCornerShape(14.dp), tint,
                        Modifier.clickable { Sfx.play(Sound.LAUNCH); onOpenPlayer() }
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            media.title, color = fg, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                            modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE)
                        )
                        Text(media.artist, color = fg.copy(0.7f), fontSize = 13.sp, maxLines = 1)
                    }
                    Spacer(Modifier.width(8.dp))
                    EqBars(tint, media.playing)
                }
                Spacer(Modifier.height(8.dp))
                SeekBar(frac, tint, { f ->
                    if (media.dur > 0) { Sfx.play(Sound.TICK); onSeek((f * media.dur).toLong()) }
                })
                Row(Modifier.fillMaxWidth()) {
                    Text(fmt(media.pos), color = fg.copy(0.6f), fontSize = 11.sp, modifier = Modifier.weight(1f))
                    Text(if (media.dur > 0) fmt(media.dur) else "--:--", color = fg.copy(0.6f), fontSize = 11.sp)
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "✦ Ask AI", color = tint, fontWeight = FontWeight.Bold, fontSize = 12.sp,
                        modifier = Modifier.clickable { open = false; onAi() }.padding(8.dp)
                    )
                    GlyphButton(Glyph.PREV, fg) { Sfx.play(Sound.MEDIA); onCmd("prev") }
                    Box(
                        Modifier.size(54.dp).clip(CircleShape).background(tint)
                            .clickable { Sfx.play(Sound.MEDIA); onCmd("toggle") },
                        contentAlignment = Alignment.Center
                    ) {
                        GlyphIcon(if (media.playing) Glyph.PAUSE else Glyph.PLAY, Color.Black.copy(0.85f), 28.dp)
                    }
                    GlyphButton(Glyph.NEXT, fg) { Sfx.play(Sound.MEDIA); onCmd("next") }
                    Text("$battery%", color = fg.copy(0.6f), fontSize = 12.sp, modifier = Modifier.padding(8.dp))
                }
            }
        } else {
            Row(
                (if (wide) Modifier.fillMaxWidth() else Modifier).padding(horizontal = if (wide) 16.dp else hPad + 4.dp, vertical = vPad + 1.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (mini && !open) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(ui.accent))
                    if (bar.showBattery) {
                        Spacer(Modifier.width(6.dp))
                        Text("$battery%", color = fg, fontSize = bar.text.sp)
                    }
                } else {
                    Text("✦", color = if (bar.color == BarColor.ACCENT) fg else ui.accent, fontSize = bar.text.sp)
                    Spacer(Modifier.width(8.dp))
                    if (wide) Spacer(Modifier.weight(1f))
                    BarInfo(bar, battery, fg, apps, onNotifs)
                }
                if (open) {
                    Spacer(Modifier.width(14.dp))
                    if (!bar.showDate) {
                        Text(LocalDate.now().format(DateTimeFormatter.ofPattern("EEE d MMM")), color = fg.copy(0.8f), fontSize = bar.text.sp)
                    }
                    if (!hasNotificationAccess(ctx)) {
                        Spacer(Modifier.width(12.dp))
                        Text(
                            "♪ Enable music", color = if (bar.color == BarColor.ACCENT) fg else ui.accent, fontSize = 12.sp,
                            modifier = Modifier.clickable {
                                try {
                                    ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                } catch (e: Exception) { }
                            }
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(
                        "Ask AI", color = if (bar.color == BarColor.ACCENT) fg else ui.accent, fontWeight = FontWeight.Bold, fontSize = bar.text.sp,
                        modifier = Modifier.clickable { open = false; onAi() }
                    )
                }
            }
        }
    }
}
