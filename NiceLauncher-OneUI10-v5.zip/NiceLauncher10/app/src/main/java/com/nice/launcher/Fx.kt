@file:OptIn(androidx.compose.animation.ExperimentalAnimationApi::class)

package com.nice.launcher

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterExitState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.GraphicsLayerScope
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext

// ------------------------------------------------------------------ enums & config

enum class ThreeD(val title: String) { OFF("Off"), SUBTLE("Subtle"), FULL("Full 3D") }

enum class PanelAnim(val title: String, val hint: String) {
    SLIDE("Slide", "Glides in from the edge"),
    ZOOM("Zoom", "Grows from the centre"),
    FADE("Fade", "Simple cross-fade"),
    FLIP("3D flip", "Tips up like a card"),
    UNFOLD("Unfold", "Opens like a book on a hinge"),
    DEPTH("Depth", "Comes forward from behind"),
    BOUNCE("Bounce", "Springs into place")
}

enum class LaunchAnim(val title: String, val enter: Int, val exit: Int) {
    SYSTEM("System default", 0, 0),
    ZOOM("Zoom", R.anim.nice_zoom_in, R.anim.nice_zoom_out),
    SLIDE("Slide up", R.anim.nice_slide_in, R.anim.nice_slide_out),
    FADE("Fade", R.anim.nice_fade_in, R.anim.nice_fade_out),
    UNFOLD("Unfold", R.anim.nice_unfold_in, R.anim.nice_unfold_out),
    POP("Pop", R.anim.nice_pop_in, R.anim.nice_pop_out)
}

enum class BarStyle(val title: String) { ISLAND("Island"), WIDE("Wide bar"), MINI("Mini") }
enum class BarColor(val title: String) { BLACK("Black"), ACCENT("Accent"), GLASS("Glass"), CUSTOM("Custom") }
enum class BarPos(val title: String) { LEFT("Left"), CENTER("Centre"), RIGHT("Right") }

/** Everything the user can edit about the top bar. */
class BarCfg(
    val style: BarStyle = BarStyle.ISLAND,
    val color: BarColor = BarColor.BLACK,
    val custom: Color = Color(0xFFFF4081),
    val alpha: Float = 1f,
    val padY: Float = 7f,
    val radius: Float = 24f,
    val text: Float = 13f,
    val showClock: Boolean = false,
    val showDate: Boolean = false,
    val showBattery: Boolean = true,
    val showNotifs: Boolean = true,
    val showMusic: Boolean = true,
    val border: Boolean = true,
    val glow: Boolean = false,
    val pos: BarPos = BarPos.CENTER,
    val top: Float = 8f
)

// ------------------------------------------------------------------ app launch animation

object LaunchFx { var mode: LaunchAnim = LaunchAnim.SYSTEM }

fun launchPkg(ctx: Context, pkg: String) {
    ctx.packageManager.getLaunchIntentForPackage(pkg)?.let {
        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val m = LaunchFx.mode
        if (m == LaunchAnim.SYSTEM) {
            ctx.startActivity(it)
        } else {
            try {
                ctx.startActivity(it, ActivityOptions.makeCustomAnimation(ctx, m.enter, m.exit).toBundle())
            } catch (e: Exception) {
                ctx.startActivity(it)
            }
        }
    }
}

// ------------------------------------------------------------------ panel animations

/**
 * Applies one open/close animation to a layer. [p] is 1 when fully shown and 0 when hidden.
 * [mag] scales the effect (1 for full panels, smaller for the home screen reveal).
 */
fun GraphicsLayerScope.applyAnim(a: PanelAnim, p: Float, mag: Float, fromEnd: Boolean) {
    val q = 1f - p
    cameraDistance = 14f * density
    when (a) {
        PanelAnim.SLIDE -> if (fromEnd) translationX = q * size.width * mag else translationY = q * size.height * mag
        PanelAnim.ZOOM -> {
            val s = 1f - 0.2f * q * mag
            scaleX *= s; scaleY *= s
        }
        PanelAnim.FADE -> {}
        PanelAnim.FLIP -> {
            rotationX = -70f * q * mag
            transformOrigin = TransformOrigin(0.5f, 1f)
        }
        PanelAnim.UNFOLD -> {
            rotationY = (if (fromEnd) 1f else -1f) * 88f * q * mag
            transformOrigin = TransformOrigin(if (fromEnd) 1f else 0f, 0.5f)
        }
        PanelAnim.DEPTH -> {
            val s = 1f + 0.3f * q * mag
            scaleX *= s; scaleY *= s
        }
        PanelAnim.BOUNCE -> {
            val s = 1f - 0.3f * q * mag
            scaleX *= s; scaleY *= s
            translationY = q * size.height * 0.25f * mag
        }
    }
}

/** Shows [content] with the open animation the user picked, and hides it with their close animation. */
@Composable
fun PanelHost(visible: Boolean, st: LauncherSettings, fromEnd: Boolean = false, content: @Composable () -> Unit) {
    val speed = st.animSpeed.coerceIn(0.4f, 2.5f)
    val dur = (340 / speed).toInt()
    val openA = st.openAnim
    val closeA = st.closeAnim
    AnimatedVisibility(
        visible,
        enter = fadeIn(tween(dur)),
        exit = fadeOut(tween((dur * 0.8f).toInt()))
    ) {
        val p by transition.animateFloat(
            transitionSpec = {
                val a = if (targetState == EnterExitState.Visible) openA else closeA
                if (a == PanelAnim.BOUNCE) spring(dampingRatio = 0.55f, stiffness = 330f * speed)
                else tween(dur, easing = FastOutSlowInEasing)
            },
            label = "panel"
        ) { if (it == EnterExitState.Visible) 1f else 0f }
        val a = if (transition.targetState == EnterExitState.Visible) openA else closeA
        Box(Modifier.fillMaxSize().graphicsLayer { applyAnim(a, p, 1f, fromEnd) }) { content() }
    }
}

// ------------------------------------------------------------------ 3D tilt

val LocalTilt = staticCompositionLocalOf<State<Offset>> { mutableStateOf(Offset.Zero) }

/** Phone tilt in the range -1..1 on both axes. It re-centres itself slowly, so it works however you hold the phone. */
@Composable
fun rememberTilt(enabled: Boolean): State<Offset> {
    val ctx = LocalContext.current
    val tilt = remember { mutableStateOf(Offset.Zero) }
    DisposableEffect(enabled) {
        if (!enabled) {
            tilt.value = Offset.Zero
            onDispose { }
        } else {
            val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
            val sensor = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            var fx = 0f; var fy = 0f; var bx = 0f; var by = 0f; var ready = false
            val l = object : SensorEventListener {
                override fun onSensorChanged(e: SensorEvent) {
                    val x = e.values[0] / 9.8f
                    val y = e.values[1] / 9.8f
                    if (!ready) { fx = x; fy = y; bx = x; by = y; ready = true }
                    fx += (x - fx) * 0.12f; fy += (y - fy) * 0.12f
                    bx += (x - bx) * 0.004f; by += (y - by) * 0.004f
                    tilt.value = Offset(((fx - bx) * 2.4f).coerceIn(-1f, 1f), ((fy - by) * 2.4f).coerceIn(-1f, 1f))
                }
                override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
            }
            if (sm != null && sensor != null) sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_GAME)
            onDispose { sm?.unregisterListener(l) }
        }
    }
    return tilt
}

/** Tilts the element towards the phone's tilt and, if [shadow] is set, lifts it off the page with a shadow. */
fun Modifier.depth3d(ui: Ui, mult: Float = 1f, shadow: Boolean = false, outline: Shape = RectangleShape): Modifier = composed {
    if (ui.threeD == ThreeD.OFF) {
        this
    } else {
        val tilt = LocalTilt.current
        val full = ui.threeD == ThreeD.FULL
        val deg = (if (full) 18f else 9f) * ui.depth * mult
        val elev = if (shadow) (if (full) 12f else 5f) * ui.depth else 0f
        this.graphicsLayer {
            val t = tilt.value
            rotationY = t.x * deg
            rotationX = -t.y * deg
            cameraDistance = 14f * density
            if (elev > 0f) {
                shadowElevation = elev * density
                shape = outline
                clip = false
            }
        }
    }
}

/** A soft shine that slides across the element as the phone tilts (Full 3D only). */
fun Modifier.gloss3d(ui: Ui): Modifier = composed {
    if (ui.threeD != ThreeD.FULL) {
        this
    } else {
        val tilt = LocalTilt.current
        this.drawWithContent {
            drawContent()
            val t = tilt.value
            val w = size.width
            drawRect(
                Brush.linearGradient(
                    listOf(Color.White.copy(0.32f), Color.Transparent),
                    start = Offset(w * (0.1f + t.x * 0.6f), 0f),
                    end = Offset(w * (0.9f + t.x * 0.6f), size.height)
                )
            )
        }
    }
}
