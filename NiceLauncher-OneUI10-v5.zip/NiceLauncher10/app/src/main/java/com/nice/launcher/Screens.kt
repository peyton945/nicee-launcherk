@file:OptIn(ExperimentalFoundationApi::class)

package com.nice.launcher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

fun expandPanel(ctx: Context) {
    try {
        val sb = ctx.getSystemService("statusbar")
        Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb)
    } catch (e: Exception) { /* not available on this device */ }
}

fun greeting(): String {
    val h = LocalDateTime.now().hour
    return when { h < 5 -> "Late night"; h < 12 -> "Good morning"; h < 18 -> "Good afternoon"; else -> "Good evening" }
}

fun initial(s: String): Char = s.firstOrNull()?.uppercaseChar()?.takeIf { it.isLetter() } ?: '#'

// ---------------------------------------------------------------- HOME
@Composable
fun HomeScreen(
    st: LauncherSettings, ui: Ui, apps: List<AppItem>,
    onDrawer: () -> Unit, onSettings: () -> Unit, onAi: () -> Unit, onEdge: () -> Unit,
    onOpen: (String) -> Unit
) {
    val ctx = LocalContext.current
    val pager = rememberPagerState(initialPage = 1) { 2 }
    val battery = rememberBattery()
    val media = rememberMedia()
    val hud = ui.homeStyle.hud
    val curPage = pager.currentPage
    var lastPage by remember { mutableIntStateOf(curPage) }
    LaunchedEffect(curPage) { if (curPage != lastPage) { Sfx.play(Sound.TICK); lastPage = curPage } }
    val dockApps = st.dock.mapNotNull { p -> apps.find { it.pkg == p } }

    Box(
        Modifier.fillMaxSize()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -100f) onDrawer() else if (total > 100f) expandPanel(ctx) },
                    onDragCancel = { total = 0f },
                    onVerticalDrag = { _, dy -> total += dy }
                )
            }
            .pointerInput(Unit) { detectTapGestures(onLongPress = { onSettings() }) }
    ) {
        if (hud) Box(Modifier.fillMaxSize().background(Color.Black.copy(0.78f)))
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            val bar = st.barCfg()
            Box(
                Modifier.fillMaxWidth().padding(top = bar.top.dp, start = 12.dp, end = 12.dp),
                contentAlignment = when (bar.pos) { BarPos.LEFT -> Alignment.CenterStart; BarPos.RIGHT -> Alignment.CenterEnd; else -> Alignment.Center }
            ) {
                Island(
                    ui, battery, media, onAi,
                    onSeek = { ms -> mediaSeek(ctx, ms) },
                    onOpenPlayer = { media?.let { m -> launchPkg(ctx, m.pkg) } },
                    bar = bar, apps = apps, onNotifs = { expandPanel(ctx) }
                ) { cmd -> mediaCmd(ctx, cmd) }
            }
            HorizontalPager(pager, Modifier.weight(1f)) { page ->
                val turn3d = ui.threeD != ThreeD.OFF && ui.pageFx
                Box(
                    Modifier.fillMaxSize().then(
                        if (turn3d) Modifier.graphicsLayer {
                            val off = (pager.currentPage - page) + pager.currentPageOffsetFraction
                            val k = if (ui.threeD == ThreeD.FULL) 48f else 26f
                            rotationY = off * k * (0.5f + ui.depth)
                            cameraDistance = 16f * density
                            transformOrigin = TransformOrigin(if (off > 0f) 1f else 0f, 0.5f)
                            alpha = (1f - kotlin.math.abs(off) * 0.4f).coerceIn(0f, 1f)
                        } else Modifier
                    )
                ) {
                    when {
                        page == 0 -> NowPage(st, ui, apps, battery, onOpen)
                        hud -> HudPage(st, ui, apps, battery, onAi, onDrawer, onOpen)
                        else -> HomePage(st, ui, apps, battery, onOpen)
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.Center) {
                repeat(2) { i ->
                    Box(
                        Modifier.padding(3.dp).size(if (pager.currentPage == i) 18.dp else 7.dp, 7.dp)
                            .clip(CircleShape)
                            .background(if (pager.currentPage == i) ui.accent else LocalContentColor.current.copy(0.3f))
                    )
                }
            }
            if (!hud) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp).depth3d(ui, 0.5f).card(ui).clickable { onAi() }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("✦", fontSize = 20.sp, color = ui.accent)
                    Spacer(Modifier.width(12.dp))
                    Text("Ask AI to do something…", color = LocalContentColor.current.copy(0.7f))
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp).depth3d(ui, 0.7f).card(ui, (ui.look.radius + 6).dp)
                        .padding(vertical = 12.dp).heightIn(min = ui.iconSize),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (dockApps.isEmpty()) {
                        Text("Long-press an app in the drawer → Pin to dock", fontSize = 13.sp, color = LocalContentColor.current.copy(0.6f))
                    }
                    dockApps.forEach { a -> AppIcon(a, ui, Modifier.pressScale({ onOpen(a.pkg) })) }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        // right-edge panel handle
        Box(
            Modifier.align(Alignment.CenterEnd).fillMaxHeight(0.4f).width(22.dp)
                .pointerInput(Unit) {
                    var total = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = { if (total < -40f) onEdge() },
                        onDragCancel = { total = 0f },
                        onHorizontalDrag = { _, dx -> total += dx }
                    )
                },
            contentAlignment = Alignment.CenterEnd
        ) {
            Box(Modifier.padding(end = 3.dp).size(4.dp, 70.dp).clip(CircleShape).background(ui.accent.copy(0.6f)))
        }
    }
}

@Composable
fun HomePage(st: LauncherSettings, ui: Ui, apps: List<AppItem>, battery: Int, onOpen: (String) -> Unit) {
    val homeApps = st.home.mapNotNull { p -> apps.find { it.pkg == p } }
    val homeWidgets = st.widgets.filter { it.onHome }
    LazyVerticalGrid(
        GridCells.Fixed(st.homeCols.coerceIn(3, 5)),
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 8.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                Box(Modifier.depth3d(ui, 0.5f)) { ClockBlock(ui) }
                Spacer(Modifier.height(16.dp))
            }
        }
        items(homeWidgets, key = { it.id }, span = { GridItemSpan(maxLineSpan) }) { w ->
            Column {
                HtmlWidget(w, ui, apps, battery)
                Spacer(Modifier.height(10.dp))
            }
        }
        if (homeApps.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    "Your home is empty. Open the drawer (swipe up), long-press an app and choose “Add to home”.",
                    fontSize = 14.sp, color = LocalContentColor.current.copy(0.6f)
                )
            }
        } else {
            items(homeApps, key = { it.pkg }) { app ->
                var menu by remember { mutableStateOf(false) }
                Box(contentAlignment = Alignment.Center) {
                    AppTile(app, ui, { onOpen(app.pkg) }, { menu = true })
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem(text = { Text("Remove from home") }, onClick = {
                            Sfx.play(Sound.TAP); menu = false; st.home = st.home - app.pkg; st.save()
                        })
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- NOW PAGE
@Composable
fun NowPage(st: LauncherSettings, ui: Ui, apps: List<AppItem>, battery: Int, onOpen: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(greeting(), fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            CalendarCard(ui, Modifier.weight(1.5f))
            BatteryCard(ui, battery, Modifier.weight(1f))
        }
        NotesCard(st, ui)
        st.widgets.forEach { w -> HtmlWidget(w, ui, apps, battery) }
        val recents = st.recents.mapNotNull { p -> apps.find { it.pkg == p } }
        Column(Modifier.fillMaxWidth().card(ui).padding(14.dp)) {
            Text("Recent", fontSize = 12.sp, color = ui.accent, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            if (recents.isEmpty()) {
                Text("Apps you open will show up here.", fontSize = 13.sp, color = LocalContentColor.current.copy(0.5f))
            } else {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    recents.forEach { a -> AppIcon(a, ui, Modifier.pressScale({ onOpen(a.pkg) })) }
                }
            }
        }
    }
}

@Composable
fun CalendarCard(ui: Ui, modifier: Modifier) {
    val today = LocalDate.now()
    val ym = YearMonth.from(today)
    val lead = ym.atDay(1).dayOfWeek.value % 7
    val days = ym.lengthOfMonth()
    val rows = (lead + days + 6) / 7
    Column(modifier.card(ui).padding(12.dp)) {
        Text(ym.format(DateTimeFormatter.ofPattern("MMMM yyyy")), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Spacer(Modifier.height(6.dp))
        Row {
            "SMTWTFS".forEach {
                Text(it.toString(), Modifier.weight(1f), fontSize = 10.sp, textAlign = TextAlign.Center,
                    color = LocalContentColor.current.copy(0.6f))
            }
        }
        for (r in 0 until rows) {
            Row {
                for (c in 0..6) {
                    val d = r * 7 + c - lead + 1
                    val isToday = d == today.dayOfMonth
                    Box(Modifier.weight(1f).height(24.dp), contentAlignment = Alignment.Center) {
                        if (d in 1..days) {
                            if (isToday) Box(Modifier.size(22.dp).clip(CircleShape).background(ui.accent))
                            Text(d.toString(), fontSize = 11.sp, color = if (isToday) Color.White else Color.Unspecified)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BatteryCard(ui: Ui, level: Int, modifier: Modifier) {
    Column(modifier.card(ui).padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(contentAlignment = Alignment.Center) {
            CircularProgressIndicator(
                progress = { level / 100f }, modifier = Modifier.size(84.dp), color = ui.accent,
                trackColor = LocalContentColor.current.copy(0.15f), strokeWidth = 8.dp
            )
            Text("$level%", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        Text("Battery", fontSize = 12.sp, color = LocalContentColor.current.copy(0.6f))
    }
}

@Composable
fun NotesCard(st: LauncherSettings, ui: Ui) {
    Column(Modifier.fillMaxWidth().card(ui).padding(14.dp)) {
        Text("Quick note", fontSize = 12.sp, color = ui.accent, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Box(Modifier.fillMaxWidth().heightIn(min = 70.dp)) {
            if (st.note.isEmpty()) {
                Text("Write something, or ask the AI to add a note…", color = LocalContentColor.current.copy(0.4f), fontSize = 14.sp)
            }
            BasicTextField(
                st.note, { st.note = it; st.save() },
                textStyle = TextStyle(color = LocalContentColor.current, fontSize = 14.sp, fontFamily = ui.look.font),
                cursorBrush = SolidColor(ui.accent), modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// ---------------------------------------------------------------- DRAWER
@Composable
fun Drawer(st: LauncherSettings, ui: Ui, apps: List<AppItem>, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val gridState = rememberLazyGridState()
    var q by remember { mutableStateOf("") }
    val list = remember(apps, q) { if (q.isBlank()) apps else apps.filter { it.label.contains(q.trim(), true) } }
    val letters = remember(list) { list.map { initial(it.label) }.distinct() }

    Box(Modifier.fillMaxSize().background(ui.look.drawerScrim).systemBarsPadding()) {
        Column(Modifier.fillMaxSize().padding(start = 16.dp, end = 8.dp)) {
            OutlinedTextField(
                q, { q = it }, singleLine = true,
                placeholder = { Text("Search apps") },
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp, end = 8.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { list.firstOrNull()?.let { onOpen(it.pkg) } })
            )
            LazyVerticalGrid(
                GridCells.Fixed(st.columns.coerceIn(3, 6)), state = gridState,
                modifier = Modifier.padding(end = 22.dp),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                items(list, key = { it.pkg }) { app ->
                    var menu by remember { mutableStateOf(false) }
                    val pinned = app.pkg in st.dock
                    val onHome = app.pkg in st.home
                    Box(contentAlignment = Alignment.Center) {
                        AppTile(app, ui, { onOpen(app.pkg) }, { menu = true })
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem(text = { Text(if (onHome) "Remove from home" else "Add to home") }, onClick = {
                                Sfx.play(Sound.TAP); menu = false
                                st.home = if (onHome) st.home - app.pkg else st.home + app.pkg
                                st.save()
                            })
                            DropdownMenuItem(text = { Text(if (pinned) "Unpin from dock" else "Pin to dock") }, onClick = {
                                Sfx.play(Sound.TAP); menu = false
                                st.dock = if (pinned) st.dock - app.pkg else if (st.dock.size < 5) st.dock + app.pkg else st.dock
                                st.save()
                            })
                            DropdownMenuItem(text = { Text("App info") }, onClick = {
                                Sfx.play(Sound.TAP); menu = false
                                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            })
                            DropdownMenuItem(text = { Text("Uninstall") }, onClick = {
                                Sfx.play(Sound.TAP); menu = false
                                ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            })
                        }
                    }
                }
            }
        }
        if (q.isBlank()) {
            Column(Modifier.align(Alignment.CenterEnd).padding(top = 60.dp)) {
                letters.forEach { c ->
                    Text(
                        c.toString(), fontSize = 10.sp, color = ui.accent,
                        modifier = Modifier.clickable {
                            Sfx.play(Sound.TICK)
                            scope.launch { gridState.scrollToItem(list.indexOfFirst { initial(it.label) == c }.coerceAtLeast(0)) }
                        }.padding(horizontal = 6.dp, vertical = 1.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun EdgePanel(st: LauncherSettings, ui: Ui, apps: List<AppItem>, onOpen: (String) -> Unit, onClose: () -> Unit) {
    val list = (st.dock + st.home + st.recents).distinct().mapNotNull { p -> apps.find { it.pkg == p } }.take(8)
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(0.35f))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() }
    ) {
        Column(
            Modifier.align(Alignment.CenterEnd).padding(end = 8.dp).card(ui).padding(12.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (list.isEmpty()) Text("Pin apps or open a few to fill this panel", fontSize = 12.sp, modifier = Modifier.width(120.dp))
            list.forEach { a -> AppIcon(a, ui, Modifier.pressScale({ onOpen(a.pkg) })) }
        }
    }
}

// ---------------------------------------------------------------- SETTINGS
@Composable
fun Section(title: String, ui: Ui, content: @Composable ColumnScope.() -> Unit) {
    Text(title, color = ui.accent, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp, start = 4.dp))
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(if (ui.look.light) Color.Black.copy(0.05f) else Color.White.copy(0.07f)).padding(16.dp),
        content = content
    )
}

@Composable
fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked, { Sfx.play(Sound.TOGGLE); onChange(it) })
    }
}

@Composable
fun PillChip(label: String, selected: Boolean, ui: Ui, dot: Color? = null, silent: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (selected) ui.accent else LocalContentColor.current.copy(0.12f))
            .clickable { if (!silent) Sfx.play(Sound.TOGGLE); onClick() }.padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (dot != null) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(dot))
            Spacer(Modifier.width(6.dp))
        }
        Text(label, fontSize = 13.sp, color = if (selected) Color.White else Color.Unspecified)
    }
}

// ---------------------------------------------------------------- AI
class Msg(val fromUser: Boolean, val text: String)

@Composable
fun AiSheet(st: LauncherSettings, ui: Ui, onClose: () -> Unit, exec: (JSONObject) -> String?) {
    val msgs = remember {
        mutableStateListOf(Msg(false, "Hey! Tell me what to do: “open Spotify”, “set a 10 minute timer”, “make it neon”, “put Camera on my dock”…"))
    }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    LaunchedEffect(msgs.size, busy) { listState.animateScrollToItem(msgs.size) }

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || busy) return
        input = ""
        msgs.add(Msg(true, text))
        if (st.apiKey.isBlank()) {
            Sfx.play(Sound.ERROR)
            msgs.add(Msg(false, "Add your OpenAI API key first: close this, long-press the home screen, open Settings → AI assistant."))
            return
        }
        busy = true
        Sfx.play(Sound.TAP)
        scope.launch {
            try {
                val hist = msgs.drop(1).takeLast(12).map { (if (it.fromUser) "user" else "assistant") to it.text }
                val r = Ai.ask(st.apiKey.trim(), st.model.trim(), hist)
                val notes = mutableListOf<String>()
                r.optJSONArray("actions")?.let { arr ->
                    for (i in 0 until arr.length()) exec(arr.getJSONObject(i))?.let { notes.add("⚠ $it") }
                }
                Sfx.play(if (notes.isEmpty()) Sound.SUCCESS else Sound.ERROR)
                msgs.add(Msg(false, (listOf(r.optString("say")) + notes).filter { it.isNotBlank() }.joinToString("\n")))
            } catch (e: Exception) {
                Sfx.play(Sound.ERROR)
                msgs.add(Msg(false, "⚠ ${e.message}"))
            }
            busy = false
        }
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val t = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (t != null) { input = t; send() }
    }

    val bg = if (ui.look.light) Color(0xF2F6F1E7) else Color(0xF2090910)
    Column(Modifier.fillMaxSize().background(bg).systemBarsPadding().imePadding().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("✦ Assistant", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = ui.accent, modifier = Modifier.weight(1f))
            Text("✕", fontSize = 24.sp, modifier = Modifier.clickable { onClose() }.padding(8.dp))
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(msgs.size) { i ->
                val m = msgs[i]
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
                    Text(
                        m.text,
                        Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(18.dp))
                            .background(if (m.fromUser) ui.accent.copy(0.85f) else LocalContentColor.current.copy(0.10f))
                            .padding(12.dp),
                        color = if (m.fromUser) Color.White else Color.Unspecified
                    )
                }
            }
            if (busy) item { Text("…", modifier = Modifier.padding(8.dp)) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Tell me what to do") }, shape = RoundedCornerShape(28.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() })
            )
            Text("🎤", fontSize = 24.sp, modifier = Modifier.clickable {
                try {
                    speech.launch(
                        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    )
                } catch (e: Exception) { msgs.add(Msg(false, "⚠ Voice input isn't available on this phone.")) }
            }.padding(8.dp))
            Button(onClick = { Sfx.play(Sound.TAP); send() }, enabled = !busy) { Text("➤") }
        }
    }
}
