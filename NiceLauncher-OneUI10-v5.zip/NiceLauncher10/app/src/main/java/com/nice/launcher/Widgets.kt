package com.nice.launcher

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.delay

// ------------------------------------------------------------------ presets
class WidgetPreset(val name: String, val height: Int, val html: String)

const val EXAMPLE_CLOCK = """<div style="height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center">
<div id="t" style="font-size:44px;font-weight:200;color:var(--accent);text-shadow:0 0 18px var(--accent)"></div>
<div id="d" style="opacity:.7;font-size:13px"></div></div>
<script>
function u(){var n=new Date();
document.getElementById('t').textContent=n.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',second:'2-digit'});
document.getElementById('d').textContent=n.toDateString()}
u();setInterval(u,1000)
</script>"""

const val EXAMPLE_PULSE = """<style>
.b{display:flex;gap:6px;align-items:flex-end;height:60px;justify-content:center}
.b i{width:10px;background:var(--accent);border-radius:5px;animation:p 1s infinite ease-in-out alternate}
.b i:nth-child(2){animation-delay:.2s}.b i:nth-child(3){animation-delay:.4s}.b i:nth-child(4){animation-delay:.6s}
@keyframes p{from{height:10px}to{height:60px}}
button{margin-top:10px;background:var(--accent);color:#fff;border:0;border-radius:20px;padding:8px 18px}
</style>
<div style="text-align:center;padding-top:10px">
<div class="b"><i></i><i></i><i></i><i></i></div>
<button onclick="Nice.openApp('Camera')">Open Camera</button></div>"""

const val PRESET_BATTERY = """<div style="height:100%;display:flex;align-items:center;justify-content:center;gap:14px">
<svg width="84" height="84" viewBox="0 0 84 84"><circle cx="42" cy="42" r="34" fill="none" stroke="currentColor" stroke-opacity=".15" stroke-width="9"/>
<circle id="r" cx="42" cy="42" r="34" fill="none" stroke="var(--accent)" stroke-width="9" stroke-linecap="round" stroke-dasharray="213.6" stroke-dashoffset="213.6" transform="rotate(-90 42 42)" style="transition:stroke-dashoffset .8s"/></svg>
<div><div id="p" style="font-size:34px;font-weight:200"></div><div style="opacity:.6;font-size:12px">Battery</div></div></div>
<script>
function u(){var b=Nice.battery();document.getElementById('p').textContent=b+'%';
document.getElementById('r').style.strokeDashoffset=213.6*(1-b/100)}
u();setInterval(u,3000)
</script>"""

const val PRESET_STOPWATCH = """<style>
button{background:var(--accent);color:#fff;border:0;border-radius:18px;padding:8px 18px;font-size:14px}
#b{background:rgba(127,127,127,.35)}
</style>
<div style="height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px">
<div id="t" style="font-size:40px;font-weight:200;font-variant-numeric:tabular-nums">00:00.0</div>
<div><button id="a">Start</button> <button id="b">Reset</button></div></div>
<script>
var run=false,st=0,el=0;
function f(){var d=el+(run?Date.now()-st:0),s=d/1000;
document.getElementById('t').textContent=('0'+Math.floor(s/60)).slice(-2)+':'+('0'+Math.floor(s%60)).slice(-2)+'.'+Math.floor(d/100%10)}
document.getElementById('a').onclick=function(){Nice.vibrate(15);Nice.sound('tap');
if(run){el+=Date.now()-st;run=false;this.textContent='Start'}else{st=Date.now();run=true;this.textContent='Stop'}f()};
document.getElementById('b').onclick=function(){Nice.vibrate(15);Nice.sound('tick');run=false;el=0;document.getElementById('a').textContent='Start';f()};
setInterval(f,100);
</script>"""

const val PRESET_DAY = """<style>.bar{height:8px;border-radius:4px;background:rgba(127,127,127,.25);margin:4px 0 12px}
.bar div{height:100%;border-radius:4px;background:var(--accent);transition:width .6s}
.l{display:flex;justify-content:space-between;font-size:12px;opacity:.75}</style>
<div style="height:100%;display:flex;flex-direction:column;justify-content:center;padding:0 6px">
<div class="l"><span>Today</span><span id="dp"></span></div><div class="bar"><div id="db"></div></div>
<div class="l"><span>This year</span><span id="yp"></span></div><div class="bar"><div id="yb"></div></div></div>
<script>
function u(){var n=new Date(),d=(n.getHours()*3600+n.getMinutes()*60+n.getSeconds())/86400;
var a=new Date(n.getFullYear(),0,1),b=new Date(n.getFullYear()+1,0,1),y=(n-a)/(b-a);
document.getElementById('dp').textContent=Math.round(d*100)+'%';document.getElementById('db').style.width=(d*100)+'%';
document.getElementById('yp').textContent=Math.round(y*100)+'%';document.getElementById('yb').style.width=(y*100)+'%'}
u();setInterval(u,10000)
</script>"""

const val PRESET_LAUNCH = """<style>button{background:var(--accent);color:#fff;border:0;border-radius:20px;padding:10px 16px;font-size:14px}</style>
<div style="height:100%;display:flex;gap:10px;align-items:center;justify-content:center;flex-wrap:wrap">
<button onclick="Nice.sound('launch');Nice.openApp('Camera')">Camera</button>
<button onclick="Nice.sound('launch');Nice.openApp('Settings')">Settings</button>
<button onclick="Nice.sound('launch');Nice.openApp('Calculator')">Calculator</button></div>"""

const val PRESET_COUNTER = """<style>button{background:var(--accent);color:#fff;border:0;border-radius:20px;padding:8px 20px;font-size:14px}</style>
<div style="height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px">
<div id="n" style="font-size:44px;font-weight:200"></div><button id="b">Tap +1</button>
<div style="font-size:11px;opacity:.5">saved on this phone</div></div>
<script>
var k='nice_counter',n=0;try{n=parseInt(localStorage.getItem(k)||'0')||0}catch(e){}
function s(){document.getElementById('n').textContent=n;try{localStorage.setItem(k,n)}catch(e){}}
document.getElementById('b').onclick=function(){n++;Nice.vibrate(10);Nice.sound('tick');s()};s();
</script>"""

val WIDGET_PRESETS = listOf(
    WidgetPreset("Clock", 120, EXAMPLE_CLOCK),
    WidgetPreset("Pulse", 130, EXAMPLE_PULSE),
    WidgetPreset("Battery ring", 120, PRESET_BATTERY),
    WidgetPreset("Stopwatch", 130, PRESET_STOPWATCH),
    WidgetPreset("Day progress", 110, PRESET_DAY),
    WidgetPreset("Quick launch", 80, PRESET_LAUNCH),
    WidgetPreset("Counter", 130, PRESET_COUNTER)
)

// ------------------------------------------------------------------ web page wrapper
fun hexOf(c: Color): String = String.format("#%06X", 0xFFFFFF and c.toArgb())

private const val WIDGET_BASE = "https://nice.widget/"

/**
 * Wraps the widget's HTML in a page with the theme colours, sensible defaults and a small
 * on-screen error line, so a broken script shows what is wrong instead of just a blank box.
 */
fun wrapHtml(body: String, ui: Ui): String =
    "<!DOCTYPE html><html><head><meta charset='utf-8'>" +
        "<meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'><style>" +
        ":root{--accent:${hexOf(ui.accent)};--accent2:${hexOf(ui.accent2)};--text:${hexOf(ui.look.text)}}" +
        "*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}" +
        "html,body{margin:0;padding:0;height:100%;background:transparent;color:var(--text);font-family:sans-serif;overflow:hidden}" +
        "button{font-family:inherit}" +
        "</style><script>" +
        "window.onerror=function(m,s,l){var e=document.getElementById('__err');" +
        "if(!e){e=document.createElement('div');e.id='__err';(document.body||document.documentElement).appendChild(e)}" +
        "e.style.cssText='position:fixed;left:0;right:0;bottom:0;font:10px monospace;color:#ff8a80;background:rgba(0,0,0,.7);padding:2px 6px;z-index:99';" +
        "e.textContent='JS error: '+m+' (line '+l+')';return true};" +
        "</script></head><body>" + body + "</body></html>"

/** Functions a widget's JavaScript can call as Nice.xxx() */
class WidgetBridge(private val ctx: Context, private val apps: () -> List<AppItem>, private val level: () -> Int) {
    private val main = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun battery(): Int = level()

    @JavascriptInterface
    fun openApp(name: String) {
        findApp(apps(), name)?.let { launchPkg(ctx, it.pkg) }
    }

    @JavascriptInterface
    fun openUrl(url: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
    }

    @JavascriptInterface
    fun vibrate(ms: Int) {
        try {
            val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(ms.toLong().coerceIn(1L, 500L), VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) { }
    }

    @JavascriptInterface
    fun toast(msg: String) {
        main.post { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }
    }

    @JavascriptInterface
    fun sound(name: String) {
        try { Sfx.play(Sound.valueOf(name.uppercase())) } catch (e: Exception) { }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun HtmlWidget(w: Widget, ui: Ui, apps: List<AppItem>, battery: Int, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val page = remember(w.html, ui.accent, ui.accent2, ui.look) { wrapHtml(w.html, ui) }
    val batteryNow = rememberUpdatedState(battery)
    val appsNow = rememberUpdatedState(apps)
    val webRef = remember { arrayOfNulls<WebView>(1) }
    var crashed by remember { mutableStateOf(false) }
    var nonce by remember { mutableIntStateOf(0) }

    // pause the widget's timers while the launcher is in the background, and free the WebView when it leaves the screen
    val owner = ctx as? LifecycleOwner
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_PAUSE) webRef[0]?.onPause()
            if (e == Lifecycle.Event.ON_RESUME) webRef[0]?.onResume()
        }
        owner?.lifecycle?.addObserver(obs)
        onDispose {
            owner?.lifecycle?.removeObserver(obs)
            webRef[0]?.let { v -> try { v.stopLoading(); v.destroy() } catch (e: Exception) { } }
            webRef[0] = null
        }
    }

    Box(modifier.fillMaxWidth().height(w.height.dp).clip(RoundedCornerShape(ui.look.radius.dp))) {
        key(nonce) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    webRef[0]?.let { old -> try { old.destroy() } catch (e: Exception) { } }
                    WebView(c).apply {
                        webRef[0] = this
                        setBackgroundColor(0)
                        overScrollMode = View.OVER_SCROLL_NEVER
                        isVerticalScrollBarEnabled = false
                        isHorizontalScrollBarEnabled = false
                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            allowFileAccess = false
                            allowContentAccess = false
                            mediaPlaybackRequiresUserGesture = false
                            setSupportZoom(false)
                            builtInZoomControls = false
                            cacheMode = WebSettings.LOAD_DEFAULT
                            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                        }
                        addJavascriptInterface(WidgetBridge(ctx, { appsNow.value }, { batteryNow.value }), "Nice")
                        webChromeClient = WebChromeClient()
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                val u = request?.url ?: return true
                                val scheme = u.scheme ?: ""
                                val own = u.host == "nice.widget"
                                if (!own && (scheme == "http" || scheme == "https" || scheme == "mailto" || scheme == "tel")) {
                                    try {
                                        ctx.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                    } catch (e: Exception) { }
                                }
                                return true
                            }

                            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                                crashed = true
                                return true
                            }
                        }
                        tag = page
                        loadDataWithBaseURL(WIDGET_BASE, page, "text/html", "utf-8", null)
                    }
                },
                update = { v ->
                    if (v.tag != page) {
                        v.tag = page
                        v.loadDataWithBaseURL(WIDGET_BASE, page, "text/html", "utf-8", null)
                    }
                }
            )
        }
        if (crashed) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(0.5f))
                    .clickable { crashed = false; nonce++ },
                contentAlignment = Alignment.Center
            ) { Text("Widget stopped. Tap to reload", color = Color.White, fontSize = 12.sp) }
        }
    }
}

@Composable
fun WidgetEditor(
    initial: Widget?, ui: Ui, apps: List<AppItem>, battery: Int,
    onSave: (Widget) -> Unit, onDelete: (() -> Unit)?, onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "My widget") }
    var html by remember { mutableStateOf(initial?.html ?: EXAMPLE_CLOCK) }
    var height by remember { mutableStateOf((initial?.height ?: 140).toString()) }
    var onHome by remember { mutableStateOf(initial?.onHome ?: false) }
    var preview by remember { mutableStateOf(true) }
    var shown by remember { mutableStateOf(html) }
    LaunchedEffect(html) { delay(600); shown = html }
    val h = (height.toIntOrNull() ?: 140).coerceIn(60, 400)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "New widget" else "Edit widget") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text("Start from a preset", fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    WIDGET_PRESETS.forEach { p ->
                        TextButton(onClick = { Sfx.play(Sound.TICK); html = p.html; height = p.height.toString() }) { Text(p.name) }
                    }
                }
                OutlinedTextField(
                    html, { html = it }, label = { Text("HTML / CSS / JS") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp),
                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    height, { height = it.filter(Char::isDigit).take(3) }, label = { Text("Height (dp)") },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                ToggleRow("Show on home screen", onHome) { onHome = it }
                ToggleRow("Live preview", preview) { preview = it }
                if (preview) {
                    Box(Modifier.fillMaxWidth().padding(top = 6.dp).clip(RoundedCornerShape(16.dp)).background(Color.Black.copy(0.25f))) {
                        HtmlWidget(Widget("preview", name, shown, h, false), ui, apps, battery)
                    }
                }
                Text(
                    "Tips: use var(--accent) and var(--text) for theme colours. JavaScript can call Nice.openApp('Spotify'), Nice.battery(), Nice.vibrate(20), Nice.toast('Hi'), Nice.sound('tap') and Nice.openUrl('https://…'). localStorage works too. Errors show at the bottom of the preview.",
                    fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                Sfx.play(Sound.SUCCESS)
                onSave(Widget(initial?.id ?: System.currentTimeMillis().toString(), name.ifBlank { "Widget" }, html, h, onHome))
            }) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (onDelete != null) TextButton(onClick = { Sfx.play(Sound.CLOSE); onDelete() }) { Text("Delete") }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    )
}
