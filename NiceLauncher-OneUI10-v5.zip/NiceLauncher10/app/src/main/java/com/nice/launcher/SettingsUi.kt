@file:OptIn(ExperimentalFoundationApi::class)

package com.nice.launcher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt
import kotlinx.coroutines.launch
import org.json.JSONObject

// ---------------------------------------------------------------- SETTINGS (v5 layout)

enum class SPage(val title: String, val glyph: String, val badge: Color) {
    APPEARANCE("Appearance", "◐", Color(0xFF7C4DFF)),
    HOME("Home screen", "⌂", Color(0xFF448AFF)),
    EFFECTS("3D & graphics", "◈", Color(0xFF00ACC1)),
    BAR("Notification bar", "▬", Color(0xFFFF9100)),
    ANIM("Animations", "↻", Color(0xFFFF4081)),
    WIDGETS("Widgets", "▦", Color(0xFF43A047)),
    SOUND("Sound", "♪", Color(0xFFAB47BC)),
    SYSTEM("System", "⚙", Color(0xFF78909C)),
    AI("AI assistant", "✧", Color(0xFF26A69A))
}

private fun subtitle(p: SPage, st: LauncherSettings): String = when (p) {
    SPage.APPEARANCE -> "${st.look.title} · ${st.shape.title} icons"
    SPage.HOME -> "${st.homeStyle.title} · ${st.homeCols} columns"
    SPage.EFFECTS -> "3D ${st.threeD.title.lowercase()} · ${st.quality.title}"
    SPage.BAR -> "${st.barStyle.title} · ${st.barColor.title.lowercase()}"
    SPage.ANIM -> "${st.openAnim.title} in · ${st.closeAnim.title} out"
    SPage.WIDGETS -> if (st.widgets.isEmpty()) "No widgets yet" else "${st.widgets.size} widget(s)"
    SPage.SOUND -> if (st.sfx) "On · ${(st.sfxVol * 100).roundToInt()}%" else "Off"
    SPage.SYSTEM -> "Default launcher, wallpaper"
    SPage.AI -> if (st.apiKey.isBlank()) "No key set" else st.model
}

@Composable
private fun MenuGroup(ui: Ui, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(top = 14.dp).clip(RoundedCornerShape(26.dp))
            .background(if (ui.look.light) Color.Black.copy(0.05f) else Color.White.copy(0.07f)).padding(6.dp),
        content = content
    )
}

@Composable
private fun MenuRow(p: SPage, sub: String, selected: Boolean, ui: Ui, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(if (selected) ui.accent.copy(0.20f) else Color.Transparent)
            .clickable { Sfx.play(Sound.TAP); onClick() }.padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(p.badge), contentAlignment = Alignment.Center) {
            Text(p.glyph, fontSize = 20.sp, color = Color.White)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(p.title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            if (sub.isNotBlank()) Text(
                sub, fontSize = 12.sp, color = LocalContentColor.current.copy(0.6f),
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        Text("›", fontSize = 24.sp, color = LocalContentColor.current.copy(0.4f))
    }
}

@Composable
private fun SettingsMenu(st: LauncherSettings, ui: Ui, selected: SPage?, onPick: (SPage) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(ui.accent.copy(0.55f), ui.accent2.copy(0.30f)))).padding(18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(52.dp).clip(CircleShape).background(Color.White.copy(0.2f)), contentAlignment = Alignment.Center) {
            Text("✦", fontSize = 26.sp, color = Color.White)
        }
        Spacer(Modifier.width(14.dp))
        Column {
            Text("Nice UI 10", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Pick a category to customise", fontSize = 12.sp, color = Color.White.copy(0.85f))
        }
    }
    listOf(
        listOf(SPage.APPEARANCE, SPage.HOME, SPage.EFFECTS),
        listOf(SPage.BAR, SPage.ANIM, SPage.WIDGETS),
        listOf(SPage.SOUND, SPage.SYSTEM, SPage.AI)
    ).forEach { group ->
        MenuGroup(ui) { group.forEach { p -> MenuRow(p, subtitle(p, st), p == selected, ui) { onPick(p) } } }
    }
}

@Composable
private fun SubLabel(text: String) {
    Text(text, fontSize = 13.sp, color = LocalContentColor.current.copy(0.65f), modifier = Modifier.padding(top = 12.dp, bottom = 8.dp))
}

@Composable
private fun <T> ChipRow(values: List<T>, sel: T, ui: Ui, title: (T) -> String, onPick: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        values.forEach { v -> PillChip(title(v), v == sel, ui) { onPick(v) } }
    }
}

@Composable
fun SettingsScreen(
    st: LauncherSettings, ui: Ui, apps: List<AppItem>,
    page: SPage?, onPage: (SPage?) -> Unit, onClose: () -> Unit
) {
    val ctx = LocalContext.current
    val battery = rememberBattery()
    val bg = if (ui.look.light) Color(0xF2F6F1E7) else Color(0xF2101018)
    val wide = LocalConfiguration.current.screenWidthDp >= 600
    var editing by remember { mutableStateOf<Widget?>(null) }
    var creating by remember { mutableStateOf(false) }

    val pageContent: @Composable (SPage) -> Unit = { p ->
        when (p) {
            SPage.APPEARANCE -> {
        Section("Look", ui) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Look.values().forEach { l ->
                    val sel = l == st.look
                    val shape = RoundedCornerShape(20.dp)
                    Box(
                        Modifier.size(92.dp, 124.dp).clip(shape)
                            .background(Brush.linearGradient(listOf(ui.accent, Color(0xFF15152A))))
                            .border(if (sel) 3.dp else 1.dp, if (sel) Color.White else Color.White.copy(0.2f), shape)
                            .clickable { Sfx.play(Sound.TOGGLE); st.look = l; st.save() }
                    ) {
                        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(l.top, l.bottom))))
                        Text(l.title, fontSize = 11.sp, color = l.text, textAlign = TextAlign.Center,
                            fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.TopCenter).padding(8.dp))
                        Box(
                            Modifier.align(Alignment.BottomCenter).padding(8.dp).fillMaxWidth().height(28.dp)
                                .clip(RoundedCornerShape((l.radius / 2).dp))
                                .background(l.card.copy(alpha = if (l.glassy) 0.3f else l.card.alpha))
                        )
                    }
                }
            }
        }

        Section("Colours & icons", ui) {
            Text("Accent")
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Accents.forEachIndexed { i, c ->
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(c)
                            .border(3.dp, if (i == st.accent) Color.White else Color.Transparent, CircleShape)
                            .clickable { Sfx.play(Sound.TICK); st.accent = i; st.save() }
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("Icon shape")
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconShape.values().forEach { s ->
                    Box(
                        Modifier.size(46.dp).clip(s.shape)
                            .background(if (s == st.shape) ui.accent else LocalContentColor.current.copy(0.25f))
                            .clickable { Sfx.play(Sound.TICK); st.shape = s; st.save() }
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Icon size: ${st.iconSize.roundToInt()}")
            Slider(st.iconSize, { Sfx.play(Sound.TICK); st.iconSize = it; st.save() }, valueRange = 44f..72f)
            Text("Glass opacity (glass looks)")
            Slider(st.glass, { Sfx.play(Sound.TICK); st.glass = it; st.save() }, valueRange = 0.05f..0.5f)
        }

        Section("Icon colours", ui) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconTint.values().forEach { s ->
                    PillChip(s.title, s == st.tint, ui) { st.tint = s; st.save() }
                }
            }
            Text("Auto = original colours on Standard, themed colours on HUD layouts. Mono is greyscale, Accent tints every icon with your accent, Rainbow gives each app its own colour.",
                fontSize = 12.sp, color = LocalContentColor.current.copy(0.55f), modifier = Modifier.padding(vertical = 8.dp))
            OutlinedTextField(
                st.tintHex, { st.tintHex = it; st.save() }, singleLine = true,
                label = { Text("Custom colour (#RRGGBB)") }, modifier = Modifier.fillMaxWidth()
            )
        }

        Section("Clock style", ui) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ClockStyle.values().forEach { s ->
                    PillChip(s.title, s == st.clock, ui) { st.clock = s; st.save() }
                }
            }
            Text("Used on the Standard home screen. HUD layouts have their own core clock.",
                fontSize = 12.sp, color = LocalContentColor.current.copy(0.55f), modifier = Modifier.padding(top = 8.dp))
        }
            }
            SPage.HOME -> {
        Section("Home layout", ui) {
            Text("Standard is the normal home screen. The others turn it into a sci-fi HUD with rings, gauges and your apps orbiting the core.",
                fontSize = 13.sp, color = LocalContentColor.current.copy(0.65f), modifier = Modifier.padding(bottom = 10.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeStyle.values().forEach { h ->
                    HomeThumb(h, h == st.homeStyle, ui) { st.homeStyle = h; st.save() }
                }
            }
        }

        Section("Layout", ui) {
            Text("Drawer columns: ${st.columns}")
            Slider(st.columns.toFloat(), { Sfx.play(Sound.TICK); st.columns = it.roundToInt(); st.save() }, valueRange = 3f..6f, steps = 2)
            Text("Home columns: ${st.homeCols}")
            Slider(st.homeCols.toFloat(), { Sfx.play(Sound.TICK); st.homeCols = it.roundToInt(); st.save() }, valueRange = 3f..5f, steps = 1)
            ToggleRow("Show app names", st.labels) { st.labels = it; st.save() }
            ToggleRow("Blur wallpaper behind panels", st.blur) { st.blur = it; st.save() }
        }
            }
            SPage.EFFECTS -> {
                Section("3D mode", ui) {
                    Text(
                        "Icons, the dock and your home pages tilt with the phone, with depth shadows and a shine that slides across the icons. Subtle is gentle, Full 3D is dramatic.",
                        fontSize = 13.sp, color = LocalContentColor.current.copy(0.65f), modifier = Modifier.padding(bottom = 10.dp)
                    )
                    ChipRow(ThreeD.values().toList(), st.threeD, ui, { it.title }) { st.threeD = it; st.save() }
                    Row(Modifier.fillMaxWidth().padding(vertical = 18.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        repeat(4) { i ->
                            Box(
                                Modifier.depth3d(ui, 1f, true, ui.shape.shape).size(56.dp).clip(ui.shape.shape)
                                    .background(Brush.linearGradient(listOf(Accents[i], Accents[(i + 2) % Accents.size]))).gloss3d(ui)
                            )
                        }
                    }
                    Text("Depth: ${(st.depth * 100).roundToInt()}%")
                    Slider(st.depth, { st.depth = it; st.save() }, valueRange = 0.2f..1f)
                    ToggleRow("Tilt with phone motion", st.motion) { st.motion = it; st.save() }
                    ToggleRow("3D page turn when swiping home", st.pageFx) { st.pageFx = it; st.save() }
                    Text(
                        "Motion tilt is paused automatically in Battery saver. Shadows and shine still show.",
                        fontSize = 12.sp, color = LocalContentColor.current.copy(0.55f), modifier = Modifier.padding(top = 6.dp)
                    )
                }
        Section("Graphics", ui) {
            Text("Quality", fontSize = 13.sp, color = LocalContentColor.current.copy(0.65f), modifier = Modifier.padding(bottom = 8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Quality.values().forEach { q ->
                    PillChip(q.title, q == st.quality, ui) { st.quality = q; st.save() }
                }
            }
            Text(
                "Battery saver turns the animations off. Ultra adds denser stars, rain and particles.",
                fontSize = 12.sp, color = LocalContentColor.current.copy(0.55f), modifier = Modifier.padding(top = 8.dp, bottom = 14.dp)
            )
            Text("Animated background", fontSize = 13.sp, color = LocalContentColor.current.copy(0.65f), modifier = Modifier.padding(bottom = 8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BackdropStyle.values().forEach { b ->
                    BackdropThumb(b, b == st.backdrop, ui) { st.backdrop = b; st.save() }
                }
            }
            Spacer(Modifier.height(10.dp))
            ToggleRow("Floating particles", st.particles) { st.particles = it; st.save() }
        }
            }
            SPage.BAR -> {
                Section("Notification bar", ui) {
                    val cfg = st.barCfg()
                    Box(
                        Modifier.fillMaxWidth().height(130.dp).clip(RoundedCornerShape(20.dp))
                            .background(Brush.linearGradient(listOf(ui.accent.copy(0.55f), Color(0xFF15152A)))).padding(10.dp),
                        contentAlignment = when (cfg.pos) { BarPos.LEFT -> Alignment.TopStart; BarPos.RIGHT -> Alignment.TopEnd; else -> Alignment.TopCenter }
                    ) {
                        Island(ui, battery, null, {}, bar = cfg, apps = apps, onCmd = {})
                    }
                    Text(
                        "Live preview. Tap it to see it expand. App icons for your notifications show up when you have some (needs notification access, below).",
                        fontSize = 12.sp, color = LocalContentColor.current.copy(0.55f), modifier = Modifier.padding(top = 8.dp)
                    )
                    SubLabel("Style")
                    ChipRow(BarStyle.values().toList(), st.barStyle, ui, { it.title }) { st.barStyle = it; st.save() }
                    SubLabel("Position")
                    ChipRow(BarPos.values().toList(), st.barPos, ui, { it.title }) { st.barPos = it; st.save() }
                    SubLabel("Colour")
                    ChipRow(BarColor.values().toList(), st.barColor, ui, { it.title }) { st.barColor = it; st.save() }
                    if (st.barColor == BarColor.CUSTOM) {
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            st.barHex, { st.barHex = it; st.save() }, singleLine = true,
                            label = { Text("Custom colour (#RRGGBB)") }, modifier = Modifier.fillMaxWidth()
                        )
                    }
                    SubLabel("Size & shape")
                    Text("Opacity: ${(st.barAlpha * 100).roundToInt()}%")
                    Slider(st.barAlpha, { st.barAlpha = it; st.save() }, valueRange = 0.2f..1f)
                    Text("Height: ${st.barPadY.roundToInt()}")
                    Slider(st.barPadY, { st.barPadY = it; st.save() }, valueRange = 3f..18f)
                    Text("Corner radius: ${st.barRadius.roundToInt()}")
                    Slider(st.barRadius, { st.barRadius = it; st.save() }, valueRange = 2f..32f)
                    Text("Text size: ${st.barText.roundToInt()}")
                    Slider(st.barText, { st.barText = it; st.save() }, valueRange = 10f..18f)
                    Text("Distance from top: ${st.barTop.roundToInt()}")
                    Slider(st.barTop, { st.barTop = it; st.save() }, valueRange = 0f..40f)
                    SubLabel("Show")
                    ToggleRow("Notification icons", st.barNotifs) { st.barNotifs = it; st.save() }
                    ToggleRow("Clock", st.barClock) { st.barClock = it; st.save() }
                    ToggleRow("Date", st.barDate) { st.barDate = it; st.save() }
                    ToggleRow("Battery", st.barBattery) { st.barBattery = it; st.save() }
                    ToggleRow("Now-playing music", st.barMusic) { st.barMusic = it; st.save() }
                    SubLabel("Effects")
                    ToggleRow("Border", st.barBorder) { st.barBorder = it; st.save() }
                    ToggleRow("Glow", st.barGlow) { st.barGlow = it; st.save() }
                }
        Section("Music bar", ui) {
            val access = hasNotificationAccess(ctx)
            Text(
                if (access) "Notification access is on. The bar at the top shows the song with album art and a progress fill. Tap it to open the full player with a seek bar and controls."
                else "To show the song that's playing, turn on notification access for Nice UI 10 and come back.",
                fontSize = 13.sp, color = LocalContentColor.current.copy(0.65f), modifier = Modifier.padding(bottom = 10.dp)
            )
            if (!access) {
                Button(onClick = { Sfx.play(Sound.TAP);
                    try { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
                }) { Text("Open notification access") }
            }
        }
            }
            SPage.ANIM -> {
                Section("Open & close animations", ui) {
                    Text(
                        "Choose how the app drawer, settings, edge panel and AI sheet appear and disappear. The home screen also plays your close animation when you come back to it.",
                        fontSize = 13.sp, color = LocalContentColor.current.copy(0.65f), modifier = Modifier.padding(bottom = 10.dp)
                    )
                    var demo by remember { mutableStateOf(true) }
                    Box(
                        Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(20.dp))
                            .background(Brush.linearGradient(listOf(ui.accent.copy(0.45f), Color(0xFF15152A)))).clipToBounds(),
                        contentAlignment = Alignment.Center
                    ) {
                        PanelHost(demo, st) {
                            Box(Modifier.fillMaxSize().padding(16.dp).card(ui), contentAlignment = Alignment.Center) {
                                Text("Preview panel", fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { Sfx.play(Sound.TAP); demo = !demo }) { Text(if (demo) "▶ Play close" else "▶ Play open") }
                    SubLabel("Open animation")
                    ChipRow(PanelAnim.values().toList(), st.openAnim, ui, { it.title }) { st.openAnim = it; st.save(); demo = false }
                    Text(st.openAnim.hint, fontSize = 12.sp, color = LocalContentColor.current.copy(0.55f), modifier = Modifier.padding(top = 6.dp))
                    SubLabel("Close animation")
                    ChipRow(PanelAnim.values().toList(), st.closeAnim, ui, { it.title }) { st.closeAnim = it; st.save(); demo = true }
                    Text(st.closeAnim.hint, fontSize = 12.sp, color = LocalContentColor.current.copy(0.55f), modifier = Modifier.padding(top = 6.dp))
                    SubLabel("Speed: ${"%.1f".format(st.animSpeed)}x")
                    Slider(st.animSpeed, { st.animSpeed = it; st.save() }, valueRange = 0.5f..2f)
                }
                Section("App launch animation", ui) {
                    Text(
                        "Used when you open an app from the launcher. System default keeps whatever your phone normally does. If the phone's own \"remove animations\" setting is on, it can override this.",
                        fontSize = 13.sp, color = LocalContentColor.current.copy(0.65f), modifier = Modifier.padding(bottom = 10.dp)
                    )
                    ChipRow(LaunchAnim.values().toList(), st.launchAnim, ui, { it.title }) { st.launchAnim = it; st.save() }
                }
                Section("Foldable screen", ui) {
                    val cw = LocalConfiguration.current.screenWidthDp
                    Text(
                        if (cw >= 600) "Inner (unfolded) screen detected · ${cw}dp wide" else "Cover / phone-size screen · ${cw}dp wide",
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(6.dp))
                    ToggleRow("Play an animation when folding / unfolding", st.foldFx) { st.foldFx = it; st.save() }
                    Text(
                        "The launcher no longer restarts when you fold or unfold, so your place is kept and the home screen can animate between the two screens. Settings switches to a two-column layout on the big screen.",
                        fontSize = 12.sp, color = LocalContentColor.current.copy(0.55f), modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
            SPage.WIDGETS -> {
        Section("HTML widgets", ui) {
            Text(
                "Build your own widgets with HTML, CSS and JavaScript. They appear on the left page, and on the home screen if you tick that. The AI can write them too: try “make a pulsing clock widget”.",
                fontSize = 13.sp, color = LocalContentColor.current.copy(0.65f), modifier = Modifier.padding(bottom = 10.dp)
            )
            st.widgets.forEach { w ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(w.name, Modifier.weight(1f))
                    TextButton(onClick = { Sfx.play(Sound.TAP); editing = w }) { Text("Edit") }
                }
            }
            Text("Quick add", fontSize = 12.sp, color = LocalContentColor.current.copy(0.55f), modifier = Modifier.padding(top = 8.dp, bottom = 6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                WIDGET_PRESETS.forEach { p ->
                    PillChip("＋ " + p.name, false, ui, silent = true) {
                        st.addWidget(p.name, p.html, p.height, false)
                        Sfx.play(Sound.SUCCESS)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Button(onClick = { Sfx.play(Sound.TAP); creating = true }) { Text("＋ Add widget") }
        }
            }
            SPage.SOUND -> {
        Section("Sound effects", ui) {
            ToggleRow("Sound effects", st.sfx) { st.sfx = it; Sfx.enabled = it; st.save() }
            Spacer(Modifier.height(6.dp))
            Text("Volume: ${(st.sfxVol * 100).roundToInt()}%")
            Slider(st.sfxVol, { st.sfxVol = it; Sfx.volume = it; Sfx.play(Sound.TICK); st.save() }, valueRange = 0f..1f)
            Text("Tap to preview", fontSize = 12.sp, color = LocalContentColor.current.copy(0.55f), modifier = Modifier.padding(bottom = 6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Sound.values().forEach { snd -> PillChip(snd.label, false, ui, silent = true) { Sfx.play(snd) } }
            }
        }
            }
            SPage.SYSTEM -> {
        Section("System", ui) {
            Button(onClick = { Sfx.play(Sound.TAP);
                try { ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
            }) { Text("Set as default launcher") }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { Sfx.play(Sound.TAP);
                try {
                    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) { }
            }) { Text("Change wallpaper") }
        }
            }
            SPage.AI -> {
        Section("AI assistant (OpenAI)", ui) {
            Text(
                "Paste an API key from platform.openai.com. It is separate from a ChatGPT subscription and billed per use. The key is stored only on this phone.",
                fontSize = 13.sp, color = LocalContentColor.current.copy(0.65f), modifier = Modifier.padding(bottom = 10.dp)
            )
            OutlinedTextField(
                st.apiKey, { st.apiKey = it; st.save() }, singleLine = true, label = { Text("API key") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                st.model, { st.model = it; st.save() }, singleLine = true,
                label = { Text("Model") }, modifier = Modifier.fillMaxWidth()
            )
        }
            }
        }
    }

    Column(Modifier.fillMaxSize().background(bg).systemBarsPadding()) {
        val sub = page != null && !wide
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            if (sub) {
                Text("‹", fontSize = 36.sp, modifier = Modifier.clickable { Sfx.play(Sound.CLOSE); onPage(null) }.padding(end = 14.dp))
            }
            Text(
                if (sub) page!!.title else "Settings",
                fontSize = if (sub) 26.sp else 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
            )
            Text("✕", fontSize = 24.sp, modifier = Modifier.clickable { onClose() }.padding(8.dp))
        }
        if (wide) {
            val cur = page ?: SPage.APPEARANCE
            Row(Modifier.fillMaxSize()) {
                Column(
                    Modifier.width(340.dp).fillMaxHeight().verticalScroll(rememberScrollState())
                        .padding(start = 16.dp, end = 8.dp, bottom = 24.dp)
                ) { SettingsMenu(st, ui, cur) { onPage(it) } }
                Column(
                    Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState())
                        .padding(start = 8.dp, end = 20.dp, bottom = 30.dp)
                ) { pageContent(cur) }
            }
        } else {
            AnimatedContent(
                page,
                transitionSpec = {
                    if (targetState != null) {
                        (slideInHorizontally { it / 3 } + fadeIn()) togetherWith (slideOutHorizontally { -it / 4 } + fadeOut())
                    } else {
                        (slideInHorizontally { -it / 3 } + fadeIn()) togetherWith (slideOutHorizontally { it / 4 } + fadeOut())
                    }
                },
                label = "settingsPage"
            ) { target ->
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 30.dp)
                ) {
                    if (target == null) SettingsMenu(st, ui, null) { onPage(it) } else pageContent(target)
                }
            }
        }
    }

    if (creating) {
        WidgetEditor(
            null, ui, apps, battery,
            onSave = { st.widgets = st.widgets + it; st.save(); creating = false },
            onDelete = null,
            onDismiss = { creating = false }
        )
    }
    editing?.let { cur ->
        WidgetEditor(
            cur, ui, apps, battery,
            onSave = { n -> st.widgets = st.widgets.map { if (it.id == n.id) n else it }; st.save(); editing = null },
            onDelete = { st.widgets = st.widgets.filter { it.id != cur.id }; st.save(); editing = null },
            onDismiss = { editing = null }
        )
    }
}
