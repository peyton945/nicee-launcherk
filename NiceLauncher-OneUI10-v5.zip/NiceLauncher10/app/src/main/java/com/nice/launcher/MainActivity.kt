package com.nice.launcher

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

enum class Screen { Home, Drawer, Settings }

class MainActivity : ComponentActivity() {
    private var homeTick by mutableIntStateOf(0)
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val st = LauncherSettings(this)
        Sfx.init(applicationContext)
        Sfx.enabled = st.sfx
        Sfx.volume = st.sfxVol
        setContent { LauncherApp(st, homeTick, resumeTick) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        homeTick++
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }
}

fun findApp(apps: List<AppItem>, name: String): AppItem? =
    apps.firstOrNull { it.label.equals(name, true) }
        ?: apps.firstOrNull { it.label.contains(name, true) }
        ?: apps.firstOrNull { name.contains(it.label, true) }

/** Runs one action returned by the AI. Returns an error note, or null on success. */
fun exec(ctx: Context, st: LauncherSettings, a: JSONObject, apps: List<AppItem>): String? = try {
    fun go(i: Intent) { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    when (a.optString("type")) {
        "open_app" -> {
            val n = a.optString("name")
            val app = findApp(apps, n)
            if (app == null) "Couldn't find an app called \"$n\"" else { launchPkg(ctx, app.pkg); null }
        }
        "open_url" -> { go(Intent(Intent.ACTION_VIEW, Uri.parse(a.optString("url")))); null }
        "web_search" -> {
            go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.optString("query")))))
            null
        }
        "set_timer" -> {
            go(Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds", 60))
                .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            null
        }
        "set_alarm" -> {
            go(Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour", 7))
                .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0))
                .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            null
        }
        "call" -> { go(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + a.optString("number")))); null }
        "set_look" -> {
            val n = a.optString("name")
            val l = Look.values().firstOrNull { it.name.equals(n, true) || it.title.contains(n, true) || n.contains(it.name, true) }
            if (l == null) "Unknown look \"$n\"" else { st.look = l; st.save(); null }
        }
        "set_accent" -> {
            val names = listOf("purple", "cyan", "pink", "green", "orange", "blue")
            val c = a.optString("color")
            val i = if (a.has("index")) a.optInt("index") else names.indexOfFirst { it.equals(c, true) }
            if (i in Accents.indices) { st.accent = i; st.save(); null } else "Unknown colour \"$c\""
        }
        "set_icon_shape" -> {
            val n = a.optString("shape")
            val s = IconShape.values().firstOrNull { it.name.equals(n, true) || it.title.equals(n, true) }
            if (s == null) "Unknown shape \"$n\"" else { st.shape = s; st.save(); null }
        }
        "pin_app" -> {
            val n = a.optString("name")
            val app = findApp(apps, n)
            if (app == null) "Couldn't find an app called \"$n\"" else {
                if (a.optString("where", "dock") == "home") st.home = (st.home + app.pkg).distinct()
                else st.dock = (st.dock + app.pkg).distinct().take(5)
                st.save()
                null
            }
        }
        "set_home_style" -> {
            val n = a.optString("name")
            val s = HomeStyle.values().firstOrNull { it.name.equals(n, true) || it.title.equals(n, true) }
            if (s == null) "Unknown layout \"$n\"" else { st.homeStyle = s; st.save(); null }
        }
        "set_clock" -> {
            val n = a.optString("style")
            val s = ClockStyle.values().firstOrNull { it.name.equals(n, true) || it.title.equals(n, true) }
            if (s == null) "Unknown clock \"$n\"" else { st.clock = s; st.save(); null }
        }
        "set_icon_tint" -> {
            val n = a.optString("mode")
            val s = IconTint.values().firstOrNull { it.name.equals(n, true) || it.title.equals(n, true) }
            if (s == null) "Unknown icon colour mode \"$n\"" else {
                st.tint = s
                if (s == IconTint.CUSTOM) st.tintHex = a.optString("color", st.tintHex)
                st.save()
                null
            }
        }
        "create_widget" -> {
            val html = a.optString("html")
            if (html.isBlank()) "The widget had no code" else {
                st.addWidget(a.optString("name", "AI widget"), html, a.optInt("height", 140).coerceIn(60, 400), a.optBoolean("on_home", false))
                null
            }
        }
        "set_quality" -> {
            val n = a.optString("name")
            val q = Quality.values().firstOrNull { it.name.equals(n, true) || it.title.equals(n, true) }
            if (q == null) "Unknown quality \"$n\"" else { st.quality = q; st.save(); null }
        }
        "set_backdrop" -> {
            val n = a.optString("name")
            val b = BackdropStyle.values().firstOrNull { it.name.equals(n, true) || it.title.equals(n, true) }
            if (b == null) "Unknown background \"$n\"" else { st.backdrop = b; st.save(); null }
        }
        "set_sound" -> {
            st.sfx = a.optBoolean("on", true)
            if (a.has("volume")) st.sfxVol = a.optDouble("volume", 0.7).toFloat().coerceIn(0f, 1f)
            Sfx.enabled = st.sfx
            Sfx.volume = st.sfxVol
            st.save()
            null
        }
        "set_3d" -> {
            val n = a.optString("mode")
            val m = ThreeD.values().firstOrNull { it.name.equals(n, true) || it.title.startsWith(n, true) }
            if (m == null) "Unknown 3D mode \"$n\"" else { st.threeD = m; st.save(); null }
        }
        "set_animation" -> {
            fun pick(n: String) = PanelAnim.values().firstOrNull { it.name.equals(n, true) || it.title.equals(n, true) }
            val o = a.optString("open"); val c = a.optString("close")
            if (o.isNotBlank()) pick(o)?.let { st.openAnim = it }
            if (c.isNotBlank()) pick(c)?.let { st.closeAnim = it }
            st.save()
            null
        }
        "add_note" -> { st.note = (st.note + "\n" + a.optString("text")).trim(); st.save(); null }
        else -> "Unknown action: ${a.optString("type")}"
    }
} catch (e: Exception) {
    "Action failed: ${e.message}"
}

@Composable
fun LauncherApp(st: LauncherSettings, homeTick: Int, resumeTick: Int) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf(emptyList<AppItem>()) }
    LaunchedEffect(resumeTick) { apps = withContext(Dispatchers.Default) { loadApps(ctx) } }
    var screen by remember { mutableStateOf(Screen.Home) }
    var showAi by remember { mutableStateOf(false) }
    var showEdge by remember { mutableStateOf(false) }
    var sPage by remember { mutableStateOf<SPage?>(null) }
    val wideScreen = LocalConfiguration.current.screenWidthDp >= 600
    LaunchedEffect(homeTick) { screen = Screen.Home; showAi = false; showEdge = false }
    LaunchedEffect(screen) { if (screen != Screen.Settings) sPage = null }
    BackHandler {
        if (showAi) showAi = false
        else if (showEdge) showEdge = false
        else if (screen == Screen.Settings && sPage != null && !wideScreen) sPage = null
        else screen = Screen.Home
    }

    val look = st.look
    val accent = Accents[st.accent.coerceIn(0, Accents.lastIndex)]
    val accent2 = Accents[(st.accent + 2) % Accents.size]
    val ui = remember(st.look, st.accent, st.glass, st.shape, st.iconSize, st.labels, st.homeStyle, st.clock, st.tint, st.tintHex, st.quality, st.backdrop, st.particles, st.threeD, st.depth, st.pageFx) {
        val tc = try { Color(android.graphics.Color.parseColor(st.tintHex.trim())) } catch (e: Exception) { Color.White }
        Ui(look, accent, accent2, st.glass, st.shape, st.iconSize.dp, st.labels, st.homeStyle, st.clock, st.tint, tc, st.quality, st.backdrop, st.particles, st.threeD, st.depth, st.pageFx)
    }

    var skipClose by remember { mutableStateOf(false) }
    val open: (String) -> Unit = { pkg ->
        Sfx.play(Sound.LAUNCH)
        skipClose = screen != Screen.Home || showEdge || showAi
        st.recents = (listOf(pkg) + st.recents.filter { it != pkg }).take(8)
        st.save()
        launchPkg(ctx, pkg)
        screen = Screen.Home
        showEdge = false
    }

    // real frosted blur of the wallpaper behind panels (Android 12+)
    val panelOpen = screen != Screen.Home || showAi || showEdge
    SideEffect { Sfx.enabled = st.sfx; Sfx.volume = st.sfxVol }
    var wasOpen by remember { mutableStateOf(false) }
    LaunchedEffect(panelOpen) {
        if (panelOpen != wasOpen) {
            if (panelOpen) Sfx.play(Sound.OPEN) else if (skipClose) skipClose = false else Sfx.play(Sound.CLOSE)
            wasOpen = panelOpen
        }
    }
    val blur by animateIntAsState(if (st.blur && panelOpen) 90 else 0, tween(300), label = "blur")
    SideEffect {
        if (Build.VERSION.SDK_INT >= 31) (ctx as? Activity)?.window?.setBackgroundBlurRadius(blur)
    }
    val homeScale by animateFloatAsState(if (panelOpen) 0.92f else 1f, tween(300), label = "hs")
    SideEffect { LaunchFx.mode = st.launchAnim }
    val tilt = rememberTilt(st.threeD != ThreeD.OFF && st.motion && st.quality.anim)

    // the home screen plays your "close" animation when you come back to it, and when the screen folds / unfolds
    val homeP = remember { Animatable(1f) }
    val revealDur = (360 / st.animSpeed.coerceIn(0.4f, 2.5f)).toInt()
    suspend fun playReveal() {
        homeP.snapTo(0f)
        if (st.closeAnim == PanelAnim.BOUNCE) homeP.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 300f))
        else homeP.animateTo(1f, tween(revealDur, easing = FastOutSlowInEasing))
    }
    LaunchedEffect(resumeTick) { if (resumeTick > 0) playReveal() }
    var lastWide by remember { mutableStateOf(wideScreen) }
    LaunchedEffect(wideScreen) {
        if (wideScreen != lastWide) {
            lastWide = wideScreen
            if (st.foldFx) playReveal()
        }
    }

    val scheme = if (look.light) lightColorScheme(primary = accent) else darkColorScheme(primary = accent)
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalContentColor provides look.text, LocalUi provides ui, LocalTilt provides tilt) {
            ProvideTextStyle(TextStyle(fontFamily = look.font)) {
                Box(Modifier.fillMaxSize()) {
                    Backdrop(ui)
                    Box(Modifier.fillMaxSize().graphicsLayer {
                        scaleX = homeScale; scaleY = homeScale
                        val p = homeP.value
                        if (p < 1f) {
                            applyAnim(st.closeAnim, p, 0.2f, false)
                            alpha = 0.35f + 0.65f * p.coerceIn(0f, 1f)
                        }
                    }) {
                        HomeScreen(st, ui, apps,
                            onDrawer = { screen = Screen.Drawer },
                            onSettings = { screen = Screen.Settings },
                            onAi = { showAi = true },
                            onEdge = { showEdge = true },
                            onOpen = open)
                    }
                    PanelHost(screen == Screen.Drawer, st) {
                        Drawer(st, ui, apps, onOpen = open)
                    }
                    PanelHost(screen == Screen.Settings, st) {
                        SettingsScreen(st, ui, apps, sPage, { sPage = it }) { screen = Screen.Home }
                    }
                    PanelHost(showEdge, st, fromEnd = true) {
                        EdgePanel(st, ui, apps, onOpen = open, onClose = { showEdge = false })
                    }
                    PanelHost(showAi, st) {
                        AiSheet(st, ui, onClose = { showAi = false }, exec = { exec(ctx, st, it, apps) })
                    }
                }
            }
        }
    }
}
