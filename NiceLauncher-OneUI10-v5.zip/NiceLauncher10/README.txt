Nice UI 10 launcher v5
======================
v5 (this version) - what's new
 * 3D mode (Settings > 3D & graphics): Off / Subtle / Full 3D. Icons, dock, clock and home pages tilt with the phone,
   get depth shadows and a moving shine, and the two home pages turn like a cube when you swipe. Depth slider, motion toggle.
 * Editable notification bar (Settings > Notification bar): Island / Wide bar / Mini, left/centre/right, colour (black, accent,
   glass, custom hex), opacity, height, corner radius, text size, distance from top, border, glow, and what it shows:
   notification app icons, clock, date, battery, now-playing music. Live preview. Notification icons need notification access.
 * Animations (Settings > Animations): separate open and close animations (Slide, Zoom, Fade, 3D flip, Unfold, Depth, Bounce) for
   the drawer, settings, edge panel and AI sheet, speed slider with a live preview, and an app-launch animation
   (System, Zoom, Slide up, Fade, Unfold, Pop). The home screen plays your close animation when you return to it.
 * Foldables: the launcher no longer restarts on fold/unfold (configChanges), the home screen animates when the screen
   size changes, and Settings becomes a two-pane layout on the big inner screen.
 * New settings design: a categorised menu with coloured icon badges and a summary of each category's current value,
   sub-pages that slide in, back arrow. Everything from v4 is still there, just regrouped.
 * AI assistant can set_3d and set_animation.

Notes
 * App CLOSE animations are controlled by the app you are leaving and by One UI, not by the launcher. The launcher controls
   how its own panels close and how the home screen appears when you come back.
 * "Remove animations" in the phone's accessibility settings can override the app-launch animation.

Nice UI 10 launcher v4
======================
v3: HUD layouts, music bar, clock styles, icon colours, HTML widgets.
v4 (this version):
 * Widgets fixed: real https base URL (localStorage + fetch work), DOM storage on, safe link handling,
   on-screen JS error line, crash recovery, timers paused when the launcher is hidden, WebView freed properly,
   home page now scrolls so widgets can never squash the app grid. New bridge: Nice.vibrate/toast/sound/openUrl.
   Widget editor has a live preview and presets; Settings > HTML widgets has one-tap "Quick add" widgets.
 * Music bar redesigned: album art, tinted from the cover, scrolling title, progress fill, full player with
   seek bar and drawn play/pause/next/prev buttons.
 * Settings > Graphics: quality (Battery saver / Balanced / High / Ultra), animated backgrounds
   (Blobs, Starfield, Waves, Cyber grid, Rain, Plain) with previews, floating particles toggle.
   Home layouts now have preview cards too. The AI assistant can change these (set_quality, set_backdrop, set_sound).
 * Sound effects for taps, long-press, opening/closing panels, launching apps, switches, sliders, music controls,
   AI replies and errors. Generated in code (no audio files). Settings > Sound effects: on/off, volume, preview.

Build: open the NiceLauncher10 folder in Android Studio and run (or ./gradlew assembleDebug).
