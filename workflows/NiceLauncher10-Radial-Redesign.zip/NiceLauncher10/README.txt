Nice UI 10 launcher: open this folder in Android Studio (Koala or newer), let Gradle sync,
press Run, then press Home and pick "Nice UI 10" -> Always.
