@file:OptIn(ExperimentalFoundationApi::class)

package com.nice.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class Ui(
    val look: Look, val accent: Color, val accent2: Color, val glass: Float,
    val shape: IconShape, val iconSize: Dp, val labels: Boolean
)

val LocalUi = compositionLocalOf<Ui> { error("Ui not provided") }

fun Modifier.card(ui: Ui, radius: Dp = ui.look.radius.dp): Modifier {
    val shape = RoundedCornerShape(radius)
    val fill = ui.look.card.copy(alpha = if (ui.look.glassy) ui.glass else ui.look.card.alpha)
    val base = if (ui.look.glow) this.shadow(12.dp, shape, ambientColor = ui.accent, spotColor = ui.accent) else this
    return base.clip(shape).background(fill).border(1.dp, ui.look.stroke(ui.accent), shape)
}

/** Bouncy press animation + haptic long-press. */
fun Modifier.pressScale(onClick: () -> Unit, onLong: (() -> Unit)? = null): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) 0.86f else 1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "press"
    )
    val hap = LocalHapticFeedback.current
    this.scale(s).combinedClickable(
        interactionSource = src, indication = null, onClick = onClick,
        onLongClick = onLong?.let { l -> { hap.performHapticFeedback(HapticFeedbackType.LongPress); l() } }
    )
}

@Composable
fun AppIcon(app: AppItem, ui: Ui, modifier: Modifier = Modifier) {
    Image(app.icon, app.label, modifier.size(ui.iconSize).clip(ui.shape.shape))
}

@Composable
fun AppTile(app: AppItem, ui: Ui, onClick: () -> Unit, onLong: (() -> Unit)? = null) {
    Column(Modifier.pressScale(onClick, onLong).padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        AppIcon(app, ui)
        if (ui.labels) {
            Spacer(Modifier.height(4.dp))
            Text(app.label, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun Backdrop(ui: Ui) {
    val t by rememberInfiniteTransition(label = "bg").animateFloat(
        0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "t"
    )
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(ui.look.top, ui.look.bottom)))
        val b = ui.look.blob
        if (b > 0f) {
            val w = size.width
            val h = size.height
            val c1 = Offset(w * (0.15f + 0.7f * t), h * (0.2f + 0.1f * t))
            val c2 = Offset(w * (0.85f - 0.7f * t), h * (0.75f - 0.1f * t))
            drawCircle(Brush.radialGradient(listOf(ui.accent.copy(b), Color.Transparent), center = c1, radius = w), radius = w, center = c1)
            drawCircle(Brush.radialGradient(listOf(ui.accent2.copy(b * 0.8f), Color.Transparent), center = c2, radius = w), radius = w, center = c2)
        }
    }
}

@Composable
fun rememberBattery(): Int {
    val ctx = LocalContext.current
    var level by remember { mutableIntStateOf(100) }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                if (l >= 0 && s > 0) level = l * 100 / s
            }
        }
        val sticky = ctx.registerReceiver(r, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (sticky != null) r.onReceive(ctx, sticky)
        onDispose { ctx.unregisterReceiver(r) }
    }
    return level
}

/** Dynamic-island style pill: tap to expand. */
@Composable
fun Island(ui: Ui, battery: Int, onAi: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(50)
    Row(
        Modifier.animateContentSize(spring(dampingRatio = 0.55f, stiffness = 300f))
            .clip(shape).background(Color.Black)
            .border(1.dp, ui.look.stroke(ui.accent), shape)
            .clickable { open = !open }
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("✦", color = ui.accent)
        Spacer(Modifier.width(8.dp))
        Text("$battery%", color = Color.White, fontSize = 13.sp)
        if (open) {
            Spacer(Modifier.width(14.dp))
            Text(LocalDate.now().format(DateTimeFormatter.ofPattern("EEE d MMM")), color = Color.White.copy(0.8f), fontSize = 13.sp)
            Spacer(Modifier.width(14.dp))
            Text("Ask AI", color = ui.accent, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                modifier = Modifier.clickable { open = false; onAi() })
        }
    }
}

@Composable
fun ClockBlock(ui: Ui) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(1000) } }
    val term = ui.look == Look.TERMINAL
    val align = if (ui.look.centered) Alignment.CenterHorizontally else Alignment.Start
    Column(Modifier.fillMaxWidth(), horizontalAlignment = align) {
        Text(
            now.format(DateTimeFormatter.ofPattern(if (term) "HH:mm:ss" else "HH:mm")),
            fontSize = if (term) 60.sp else 88.sp,
            fontWeight = if (ui.look == Look.CLASSIC) FontWeight.Light else FontWeight.Thin,
            color = if (ui.look.glow) ui.accent else Color.Unspecified
        )
        Text(
            now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")),
            fontSize = 18.sp, color = LocalContentColor.current.copy(0.8f)
        )
    }
}
