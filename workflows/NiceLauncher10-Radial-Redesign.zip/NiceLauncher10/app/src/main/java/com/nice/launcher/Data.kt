package com.nice.launcher

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontFamily
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

val Accents = listOf(
    Color(0xFFC16A86), Color(0xFF00E5FF), Color(0xFFFF4081),
    Color(0xFF69F0AE), Color(0xFFFFAB40), Color(0xFF448AFF)
)

enum class IconShape(val title: String, val shape: Shape) {
    CIRCLE("Circle", RoundedCornerShape(50)),
    SQUIRCLE("Squircle", RoundedCornerShape(32)),
    ROUNDED("Rounded", RoundedCornerShape(16)),
    TEARDROP("Teardrop", RoundedCornerShape(50, 50, 50, 12)),
    SQUARE("Square", RoundedCornerShape(4))
}

enum class Look(
    val title: String, val light: Boolean, val text: Color, val top: Color, val bottom: Color,
    val card: Color, val glassy: Boolean, val radius: Int, val glow: Boolean, val blob: Float,
    val centered: Boolean, val font: FontFamily, val drawerScrim: Color
) {
    LIQUID("Radial Modern", false, Color(0xFFF7EDF1), Color(0xFF0B080C), Color(0xFF160A11), Color(0xFF24141D), false, 26, false, 0.08f, true, FontFamily.Default, Color(0xEE0B080C)),
    CLASSIC("One UI Classic", false, Color.White, Color(0x33000000), Color(0x99000000), Color(0xEB26262B), false, 28, false, 0f, false, FontFamily.Default, Color(0xCC0C0C10)),
    NEON("Neon Cyber", false, Color(0xFFEAFBFF), Color(0xE6050510), Color(0xF2000000), Color(0x99080818), false, 18, true, 0.35f, false, FontFamily.SansSerif, Color(0xE6000000)),
    AURORA("Aurora", false, Color.White, Color(0x55000022), Color(0x99000011), Color.White, true, 34, false, 0.55f, true, FontFamily.Default, Color(0x99000018)),
    PAPER("Paper", true, Color(0xFF1C1B1F), Color(0xCCF6F1E7), Color(0xE6E9E0D0), Color(0xCCFFFFFF), false, 26, false, 0f, true, FontFamily.Serif, Color(0xEBF6F1E7)),
    TERMINAL("Terminal", false, Color(0xFF39FF14), Color(0xF5000000), Color(0xF5000000), Color(0xB3001400), false, 4, false, 0f, false, FontFamily.Monospace, Color(0xF5000000));

    fun stroke(accent: Color): Brush = when (this) {
        LIQUID, AURORA -> Brush.linearGradient(listOf(Color.White.copy(0.7f), Color.White.copy(0.05f), Color.White.copy(0.35f)))
        NEON -> SolidColor(accent)
        TERMINAL -> SolidColor(text.copy(0.7f))
        PAPER -> SolidColor(Color.Black.copy(0.08f))
        CLASSIC -> SolidColor(Color.White.copy(0.08f))
    }
}

class LauncherSettings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("nice_launcher", Context.MODE_PRIVATE)
    private fun list(k: String) = (sp.getString(k, "") ?: "").split(",").filter { it.isNotBlank() }

    var apiKey by mutableStateOf(sp.getString("key", "") ?: "")
    var model by mutableStateOf(sp.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini")
    var look by mutableStateOf(runCatching { Look.valueOf(sp.getString("look", "LIQUID")!!) }.getOrDefault(Look.LIQUID))
    var shape by mutableStateOf(runCatching { IconShape.valueOf(sp.getString("shape", "SQUIRCLE")!!) }.getOrDefault(IconShape.SQUIRCLE))
    var accent by mutableStateOf(sp.getInt("accent", 0))
    var glass by mutableStateOf(sp.getFloat("glass", 0.18f))
    var iconSize by mutableStateOf(sp.getFloat("isize", 56f))
    var columns by mutableStateOf(sp.getInt("cols", 4))
    var homeCols by mutableStateOf(sp.getInt("hcols", 4))
    var labels by mutableStateOf(sp.getBoolean("labels", true))
    var blur by mutableStateOf(sp.getBoolean("blur", true))
    var dock by mutableStateOf(list("dock"))
    var home by mutableStateOf(list("home"))
    var recents by mutableStateOf(list("recents"))
    var note by mutableStateOf(sp.getString("note", "") ?: "")

    fun save() {
        sp.edit()
            .putString("key", apiKey).putString("model", model)
            .putString("look", look.name).putString("shape", shape.name)
            .putInt("accent", accent).putFloat("glass", glass).putFloat("isize", iconSize)
            .putInt("cols", columns).putInt("hcols", homeCols)
            .putBoolean("labels", labels).putBoolean("blur", blur)
            .putString("dock", dock.joinToString(",")).putString("home", home.joinToString(","))
            .putString("recents", recents.joinToString(",")).putString("note", note)
            .apply()
    }
}

class AppItem(val label: String, val pkg: String, val icon: ImageBitmap)

private val iconCache = HashMap<String, ImageBitmap>()

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(q, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .distinctBy { it.activityInfo.packageName }
        .map { ri ->
            val p = ri.activityInfo.packageName
            AppItem(
                ri.loadLabel(pm).toString(), p,
                iconCache.getOrPut(p) { ri.loadIcon(pm).toBitmap(160, 160).asImageBitmap() }
            )
        }
        .sortedBy { it.label.lowercase() }
}

object Ai {
    private const val SYSTEM = """You are the assistant built into an Android launcher called Nice UI 10. The user gives you commands. 
Respond ONLY with a JSON object: {"say": "short friendly reply", "actions": [ ... ]}.
Available action objects:
{"type":"open_app","name":"App name"}
{"type":"open_url","url":"https://..."}
{"type":"web_search","query":"..."}
{"type":"set_timer","seconds":600,"label":"..."}
{"type":"set_alarm","hour":7,"minute":30,"label":"..."}
{"type":"call","number":"+123456789"}
{"type":"set_look","name":"liquid|classic|neon|aurora|paper|terminal"}
{"type":"set_accent","color":"purple|cyan|pink|green|orange|blue"}
{"type":"set_icon_shape","shape":"circle|squircle|rounded|teardrop|square"}
{"type":"pin_app","name":"App name","where":"dock|home"}
{"type":"add_note","text":"..."}
You can restyle the launcher with set_look, set_accent and set_icon_shape when asked to change how it looks.
Use an empty actions array for plain conversation. Only include actions the user asked for."""

    suspend fun ask(key: String, model: String, history: List<Pair<String, String>>): JSONObject =
        withContext(Dispatchers.IO) {
            val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", SYSTEM))
            history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
            val body = JSONObject()
                .put("model", model)
                .put("response_format", JSONObject().put("type", "json_object"))
                .put("messages", msgs)
            val c = URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Content-Type", "application/json")
            c.doOutput = true
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = try { JSONObject(text).getJSONObject("error").getString("message") } catch (e: Exception) { text.take(200) }
                throw IllegalStateException("OpenAI error $code: $msg")
            }
            val content = JSONObject(text).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
            JSONObject(content)
        }
}
